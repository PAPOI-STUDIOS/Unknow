// ANILLO CERO — arranque, bucle principal y reglas de la partida.
import * as THREE from 'three';
import { Input, requestGamePointerLock } from './input.js';
import { World, buildArena } from './world.js';
import { BuildSystem } from './build.js';
import { Player } from './player.js';
import { Bot } from './bots.js';
import { Items } from './items.js';
import { Zone } from './zone.js';
import { FX } from './fx.js';
import { Hud } from './hud.js';
import { Sfx } from './audio.js';
import { Assets } from './assets.js';
import { biomeAt, coastRadius } from './terrain.js';

const $ = (id) => document.getElementById(id);
const canvas = $('game');
const params = new URLSearchParams(location.search);
const TOUCH_DEVICE = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
const NO_LOCK = params.has('nolock') || TOUCH_DEVICE; // para pruebas automáticas sin captura de puntero

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, TOUCH_DEVICE ? 0.9 : 1.35));
renderer.shadowMap.enabled = !TOUCH_DEVICE;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const input = new Input();
input.freeLook = NO_LOCK;
const hud = new Hud();
const sfx = new Sfx();
const assets = new Assets();
const SUN_DIR = new THREE.Vector3(0.55, 0.62, 0.35).normalize();

function makeSky() {
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { sun: { value: SUN_DIR } },
    vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: `
      varying vec3 vDir; uniform vec3 sun;
      void main(){
        vec3 d = normalize(vDir);
        float h = d.y;
        vec3 hor = vec3(0.88, 0.89, 0.81), mid = vec3(0.40, 0.69, 0.85), top = vec3(0.12, 0.35, 0.60);
        vec3 c = mix(hor, mid, smoothstep(0.0, 0.28, h));
        c = mix(c, top, smoothstep(0.2, 0.8, h));
        c = mix(c, hor * 0.92, 1.0 - smoothstep(-0.2, 0.0, h));
        float s = max(dot(d, sun), 0.0);
        c += vec3(1.0, 0.85, 0.6) * pow(s, 220.0) * 1.5 + vec3(1.0, 0.55, 0.35) * pow(s, 8.0) * 0.28;
        gl_FragColor = vec4(c, 1.0);
      }`,
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(700, 32, 16), mat);
  m.frustumCulled = false;
  return m;
}

// Mezcla de sonido ambiente según dónde está el jugador.
function ambienceAt(x, z) {
  const biome = biomeAt(x, z);
  const inland = coastRadius(Math.atan2(z, x)) - Math.hypot(x, z);
  return {
    ocean: Math.max(0, Math.min(1, 1 - inland / 50)),
    forest: biome === 'forest' ? 1 : 0,
    meadow: biome === 'meadow' ? 1 : biome === 'compound' || biome === 'forest' ? 0.3 : 0,
    snow: biome === 'snow' ? 1 : 0,
    desert: biome === 'desert' ? 1 : 0,
    compound: biome === 'compound' ? 1 : 0,
  };
}

class Game {
  constructor(mode) {
    this.mode = mode;
    this.assets = assets;
    this.ambientT = 0;
    this.input = input;
    this.hud = hud;
    this.sfx = sfx;
    this.time = 0;
    this.over = false;
    this.overT = 0;

    const scene = this.scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xb6d4d8, TOUCH_DEVICE ? 95 : 150, TOUCH_DEVICE ? 330 : 540);
    this.camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.1, 900);
    this.sky = makeSky();
    scene.add(this.sky);
    scene.add(new THREE.HemisphereLight(0xc8e6ff, 0x737558, 1.65));
    const sun = this.sun = new THREE.DirectionalLight(0xffe5bc, 2.6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(TOUCH_DEVICE ? 512 : 1536, TOUCH_DEVICE ? 512 : 1536);
    const sc = sun.shadow.camera;
    sc.left = -55; sc.right = 55; sc.top = 55; sc.bottom = -55; sc.near = 1; sc.far = 260;
    sun.shadow.bias = -0.0006;
    sun.shadow.normalBias = 0.04;
    scene.add(sun, sun.target);

    this.world = new World(scene);
    buildArena(this.world, scene, (Math.random() * 1e9) | 0, mode, assets);
    // Frustum culling por bounding sphere + lista de geometría estática apta
    // para pruebas conservadoras de oclusión contra los colisionadores del mapa.
    this.occlusionCandidates = [];
    this.occlusionCursor = 0;
    scene.traverse((o) => {
      if (!o.isMesh || !o.geometry) return;
      o.frustumCulled = true;
      if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere();
      const radius = o.geometry.boundingSphere?.radius || 0;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      if (radius > 0.45 && radius < 7 && mats.every(m => m && !m.transparent && m.opacity >= 0.98)) {
        this.occlusionCandidates.push({ mesh: o, wasVisible: o.visible });
      }
    });
    this.fx = new FX(scene, this.camera, $('floaters'));
    this.actors = [];
    this.build = mode === 'build' ? new BuildSystem(this) : null;

    const spawns = this.world.spawns;
    this.player = new Player(this, spawns[0]);
    this.actors.push(this.player);
    this.bots = [];
    for (let i = 1; i < spawns.length; i++) {
      const bot = new Bot(this, i - 1, spawns[i]);
      this.bots.push(bot);
      this.actors.push(bot);
    }
    this.items = new Items(this);
    this.zone = new Zone(this, (Math.random() - 0.5) * 50, (Math.random() - 0.5) * 50);
    hud.start(this);
    this.player.updateCamera(0.016);
  }

  updateOcclusionCulling() {
    if (!this.occlusionCandidates?.length || !this.player?.alive) return;
    const cam = this.camera.position, dir = new THREE.Vector3();
    // Cuatro comprobaciones por ciclo: coste acotado para móviles de gama baja.
    for (let n = 0; n < 4; n++) {
      const item = this.occlusionCandidates[this.occlusionCursor++ % this.occlusionCandidates.length];
      const mesh = item.mesh;
      if (!mesh.parent) continue;
      mesh.updateWorldMatrix(true, false);
      const sphere = mesh.geometry.boundingSphere;
      const center = sphere.center.clone().applyMatrix4(mesh.matrixWorld);
      dir.subVectors(center, cam);
      const distance = dir.length();
      if (distance < 2 || distance > 260) { mesh.visible = item.wasVisible; continue; }
      dir.multiplyScalar(1 / distance);
      const hit = this.world.raycast(cam.x, cam.y, cam.z, dir.x, dir.y, dir.z, distance);
      const radius = sphere.radius * Math.max(mesh.scale.x, mesh.scale.y, mesh.scale.z);
      // Margen evita ocultar el propio objeto por su colisionador.
      mesh.visible = item.wasVisible && !(hit && hit.t < distance - radius - 0.55);
    }
  }

  get aliveCount() {
    let n = 0;
    for (const a of this.actors) if (a.alive) n++;
    return n;
  }

  update(dt) {
    this.time += dt;
    this.world.update?.(dt, this.time);
    this.player.update(dt);
    for (const b of this.bots) b.update(dt);
    if (this.build) this.build.update(dt);
    this.items.update(dt);
    this.zone.update(dt);
    this.fx.update(dt);
    hud.update(dt);

    const p = this.player.body;
    this.sun.target.position.set(p.x, p.y, p.z);
    this.sun.position.set(p.x + SUN_DIR.x * 120, p.y + SUN_DIR.y * 120, p.z + SUN_DIR.z * 120);
    this.sky.position.copy(this.camera.position);

    this.ambientT -= dt;
    if (this.ambientT <= 0) { this.ambientT = 0.3; sfx.ambience(ambienceAt(p.x, p.z)); }
    if (this.player.alive && this.player.health <= 30 && !this.over) sfx.lowHealth();

    if (this.over) {
      this.overT += dt;
      if (this.overT > 1.4 && !this.shown) { this.shown = true; showEnd(this); }
    }
  }

  // --- Reglas ---
  damageActor(victim, amount, attacker, head, point) {
    if (!victim.alive || this.over && victim.isPlayer) return;
    const hadShield = victim.shield > 0;
    const s = Math.min(victim.shield, amount);
    victim.shield -= s;
    victim.health -= amount - s;
    const dead = victim.health <= 0;
    if (attacker && attacker.isPlayer) {
      hud.hitmarker(head, dead);
      if (point) this.fx.damageNumber(point, amount, head, hadShield);
      sfx.hit(head);
    }
    if (victim.isPlayer) {
      let angle = null;
      if (attacker) {
        const dx = attacker.body.x - victim.body.x, dz = attacker.body.z - victim.body.z, y = victim.yaw;
        angle = Math.atan2(dx * Math.cos(y) - dz * Math.sin(y), -dx * Math.sin(y) - dz * Math.cos(y));
      }
      hud.hurt(amount, angle);
      if (attacker) sfx.hurt(); else sfx.zoneBurn();
      if (hadShield && victim.shield <= 0) sfx.shieldBreak();
    } else victim.onDamaged(attacker);
    if (dead) this.kill(victim, attacker);
  }

  kill(victim, attacker) {
    victim.alive = false;
    victim.health = 0;
    victim.die();
    const b = victim.body;
    if (attacker) {
      attacker.kills++;
      hud.feed(`<b>${attacker.name}</b> eliminó a <b>${victim.name}</b>`, attacker.isPlayer || victim.isPlayer);
    } else hud.feed(`<b>${victim.name}</b> cayó fuera del anillo`, victim.isPlayer);
    if (!victim.isPlayer) {
      this.items.dropLoot(b.x, b.y, b.z, false);
      const pb = this.player.body, far = Math.hypot(pb.x - b.x, pb.z - b.z);
      sfx.kill(attacker && attacker.isPlayer ? 1 : Math.max(0, 1 - far / 70) * 0.7);
    }
    const alive = this.aliveCount;
    if (victim.isPlayer) this.finish(false, alive + 1);
    else if (alive === 1 && this.player.alive) this.finish(true, 1);
  }

  finish(win, rank) {
    if (this.over) return;
    this.over = true;
    this.win = win;
    this.rank = rank;
    if (win) sfx.win(); else sfx.lose();
  }

  onBuilt(piece) {
    const p = this.player.body, m = piece.mesh.position;
    if (piece.owner === this.player || Math.hypot(m.x - p.x, m.z - p.z) < 40) sfx.build();
  }

  onBroken(piece) {
    const p = this.player.body, m = piece.mesh.position;
    sfx.breakPiece(Math.max(0, 1 - Math.hypot(m.x - p.x, m.z - p.z) / 60));
  }

  dispose() {
    this.fx.clear();
    const geometries = new Set(), materials = new Set(), textures = new Set();
    this.scene.traverse((o) => {
      if (o.isInstancedMesh) o.dispose();
      if (o.geometry) geometries.add(o.geometry);
      if (o.material) {
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        for (const m of mats) {
          materials.add(m);
          for (const value of Object.values(m)) if (value?.isTexture) textures.add(value);
        }
      }
    });
    for (const texture of textures) texture.dispose();
    for (const material of materials) material.dispose();
    for (const geometry of geometries) geometry.dispose();
    this.sun.shadow.dispose();
  }
}

// ---------------------------------------------------------------------------
// Estados: menú → jugando ⇄ pausa → fin
// ---------------------------------------------------------------------------
let game = null;
let state = 'menu';
let lastMode = 'build';

function show(id, on) { $(id).classList.toggle('hidden', !on); }

let pointerLockPending = false;
async function lockPointer() {
  if (NO_LOCK || input.locked || pointerLockPending) return;
  pointerLockPending = true;
  try {
    await requestGamePointerLock(canvas);
  } catch {
    pause(); // La partida no avanza sin control del ratón si se rechaza la captura.
  } finally {
    pointerLockPending = false;
  }
}

function startMatch(mode) {
  lastMode = mode;
  sfx.init();
  if (game) game.dispose();
  game = new Game(mode);
  // La primera vez las muestras aún se están decodificando.
  const started = game;
  sfx.decoding?.then(() => { if (game === started && started.time < 4) sfx.start(); });
  window.__game = game;
  show('menu', false); show('end', false); show('pause', false); show('touch-controls', TOUCH_DEVICE);
  input.clear();
  input.enabled = true;
  state = 'playing';
  lockPointer();
}

function pause() {
  if (state !== 'playing') return;
  state = 'paused';
  sfx.ambience(null);
  input.enabled = false;
  input.clear();
  show('pause', true); show('touch-controls', false);
}

function resume() {
  if (state !== 'paused') return;
  show('pause', false);
  input.clear();
  input.enabled = true;
  state = 'playing';
  lockPointer();
}

function toMenu() {
  state = 'menu';
  sfx.ambience(null);
  input.enabled = false;
  hud.hide();
  show('pause', false); show('end', false); show('menu', true); show('touch-controls', false);
  if (document.pointerLockElement) document.exitPointerLock();
}

function showEnd(g) {
  state = 'ended';
  input.enabled = false;
  input.clear();
  if (document.pointerLockElement) document.exitPointerLock();
  const t = $('endtitle');
  t.textContent = g.win ? 'VICTORIA' : 'ELIMINADO';
  t.className = g.win ? 'win' : 'lose';
  $('endsub').textContent = g.win
    ? `Último androide en pie · ${g.player.kills} bajas`
    : `Puesto n.º ${g.rank} de ${g.actors.length} · ${g.player.kills} bajas`;
  show('end', true); show('touch-controls', false);
}

document.querySelectorAll('.mode').forEach((b) => b.addEventListener('click', () => startMatch(b.dataset.mode)));
document.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => sfx.ui()));

// Modelos, texturas y sonidos se cargan antes de poder empezar. Si alguno
// falla, el juego arranca igualmente con sus formas básicas.
const modeButtons = [...document.querySelectorAll('.mode')], loadingEl = $('loading');
modeButtons.forEach((b) => { b.disabled = true; });
assets.load((progress) => { loadingEl.textContent = `Cargando recursos… ${Math.round(progress * 100)} %`; })
  .catch((error) => console.warn('No se pudieron cargar los recursos:', error))
  .then(() => {
    sfx.setSources(assets.audio);
    modeButtons.forEach((b) => { b.disabled = false; });
    loadingEl.textContent = assets.failed.length
      ? `Faltan ${assets.failed.length} recursos; se usarán formas básicas en su lugar.`
      : '';
    loadingEl.classList.toggle('hidden', !assets.failed.length);
    window.__assets = assets;
  });
$('resume').addEventListener('click', resume);
$('quit').addEventListener('click', toMenu);
$('again').addEventListener('click', () => startMatch(lastMode));
$('tomenu').addEventListener('click', toMenu);
canvas.addEventListener('click', () => { if (!TOUCH_DEVICE && state === 'playing' && !input.locked) lockPointer(); });

document.addEventListener('pointerlockchange', () => {
  input.setLocked(document.pointerLockElement === canvas);
  if (!input.locked && state === 'playing' && !NO_LOCK) pause();
});
document.addEventListener('pointerlockerror', () => {
  // Las versiones antiguas informan errores por evento, sin devolver Promise.
  if (!pointerLockPending && !input.locked && !NO_LOCK) pause();
});
addEventListener('keydown', (e) => {
  if (e.code === 'Escape' && NO_LOCK) { if (state === 'playing') pause(); else if (state === 'paused') resume(); }
});
addEventListener('blur', () => { if (!NO_LOCK) pause(); });

function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  if (game) { game.camera.aspect = innerWidth / innerHeight; game.camera.updateProjectionMatrix(); }
}
addEventListener('resize', resize);

// Escena de fondo para el menú: una partida de exhibición en pausa visual.
let last = performance.now();
function frame(now) {
  const dt = Math.min((now - last) / 1000, 1 / 30);
  last = now;
  if (game) {
    if (state === 'playing' || state === 'ended') game.update(dt);
    game.camera.updateMatrixWorld();
    // Frustum explícito para mantener matrices y límites actualizados en móvil.
    game._viewFrustum ||= new THREE.Frustum();
    game._projectionView ||= new THREE.Matrix4();
    game._projectionView.multiplyMatrices(game.camera.projectionMatrix, game.camera.matrixWorldInverse);
    game._viewFrustum.setFromProjectionMatrix(game._projectionView);
    if (TOUCH_DEVICE && (Math.floor(now / 100) % 2 === 0)) game.updateOcclusionCulling();
    renderer.render(game.scene, game.camera);
  }
  input.endFrame();
  requestAnimationFrame(frame);
}

resize();
requestAnimationFrame(frame);
window.__state = () => state;
window.__renderer = renderer; // para medir rendimiento desde la consola

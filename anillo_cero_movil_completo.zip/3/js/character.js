// Androide de armadura facetada y articulaciones mecánicas, animado sin clips externos.
import * as THREE from 'three';
import { damp, clamp, lerp } from './util.js';

const DOWN = new THREE.Vector3(0, -1, 0);
const L1 = 0.31, L2 = 0.31;           // brazo y antebrazo
const THIGH = 0.45, SHIN = 0.5, HIP_Y = 0.95;

function mat(color, extra) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.3, flatShading: true, ...extra });
}
function part(geo, material, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}
const shapeCache = new Map();
function cachedShape(key, create) {
  if (!shapeCache.has(key)) shapeCache.set(key, create());
  return shapeCache.get(key);
}
const box = (w, h, d) => cachedShape(`box:${w},${h},${d}`, () => new THREE.BoxGeometry(w, h, d));
const cylinder = (r, h, n = 10) => cachedShape(`cyl:${r},${h},${n}`, () => new THREE.CylinderGeometry(r, r, h, n));
const joint = (r) => cachedShape(`joint:${r}`, () => new THREE.IcosahedronGeometry(r, 1));

// Placas con esquinas recortadas y cantos biselados: silueta legible sin texturas.
function armor(w, h, d) {
  return cachedShape(`armor:${w},${h},${d}`, () => {
    const b = Math.min(0.014, d * 0.2, w * 0.08, h * 0.08);
    const x = w / 2 - b, y = h / 2 - b, c = Math.min(x, y) * 0.32;
    const shape = new THREE.Shape();
    shape.moveTo(-x + c, -y);
    shape.lineTo(x - c, -y); shape.lineTo(x, -y + c);
    shape.lineTo(x, y - c); shape.lineTo(x - c, y);
    shape.lineTo(-x + c, y); shape.lineTo(-x, y - c);
    shape.lineTo(-x, -y + c); shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: d - b * 2, steps: 1, bevelEnabled: true,
      bevelThickness: b, bevelSize: b, bevelSegments: 1, curveSegments: 1,
    });
    geo.translate(0, 0, -d / 2 + b);
    return geo;
  });
}

// Cada conjunto rígido se dibuja como una sola malla de color y otra luminosa.
// El detalle añadido no crea una llamada de dibujo por cada tornillo o placa.
function bakeAssembly(group, surface, glow) {
  for (const luminous of [false, true]) {
    const positions = [], normals = [], colors = [], meshes = [];
    for (const mesh of group.children) {
      if (!mesh.isMesh || !!mesh.userData.luminous !== luminous) continue;
      mesh.updateMatrix();
      const geo = mesh.geometry, pos = geo.attributes.position, normal = geo.attributes.normal;
      const index = geo.index, n = index ? index.count : pos.count;
      const point = new THREE.Vector3(), direction = new THREE.Vector3();
      const normalMatrix = new THREE.Matrix3().getNormalMatrix(mesh.matrix);
      const color = mesh.material.color;
      for (let i = 0; i < n; i++) {
        const j = index ? index.getX(i) : i;
        point.fromBufferAttribute(pos, j).applyMatrix4(mesh.matrix);
        direction.fromBufferAttribute(normal, j).applyNormalMatrix(normalMatrix);
        positions.push(point.x, point.y, point.z);
        normals.push(direction.x, direction.y, direction.z);
        colors.push(color.r, color.g, color.b);
      }
      meshes.push(mesh);
    }
    if (!meshes.length) continue;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.computeBoundingSphere();
    for (const mesh of meshes) group.remove(mesh);
    const merged = part(geo, luminous ? glow : surface);
    merged.receiveShadow = true;
    merged.castShadow = !luminous;
    group.add(merged);
  }
}

// --- Armas -----------------------------------------------------------------
// Encaje de cada modelo en la mano: largo en metros y, como fracciones del
// modelo, dónde quedan la empuñadura (desde la culata, desde abajo), el eje
// del cañón y el guardamanos que sujeta la mano izquierda.
const GUN_MODELS = {
  rifle: { model: 'gun_rifle', length: 0.92, grip: [0.30, 0.37], axis: 0.69, fore: 0.72 },
  shotgun: { model: 'gun_shotgun', length: 0.95, grip: [0.26, 0.32], axis: 0.73, fore: 0.74 },
  smg: { model: 'gun_smg', length: 0.55, grip: [0.33, 0.43], axis: 0.72, fore: 0.68 },
  tool: { model: 'build_tool', length: 0.34, grip: [0.18, 0.22], axis: 0.70, fore: 0.6 },
};

function muzzleFlash(muzzle) {
  const flash = new THREE.Mesh(
    new THREE.ConeGeometry(0.075, 0.3, 6, 1, true),
    new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
  );
  flash.rotation.x = Math.PI / 2;
  flash.position.copy(muzzle.position);
  flash.position.z -= 0.15;
  flash.visible = false;
  return flash;
}

// Arma a partir de un modelo GLB normalizado (cañón hacia -Z, base en y = 0).
function modelGun(kind, assets) {
  const fit = GUN_MODELS[kind], model = assets?.model?.(fit?.model);
  if (!model) return null;
  const g = new THREE.Group(), s = model.size, L = fit.length;
  const h = L * s.y / s.z, w = L * s.x / s.z;
  const rear = fit.grip[0] * L + 0.03, bottom = -0.05 - fit.grip[1] * h;
  for (const p of model.parts) {
    const mesh = new THREE.Mesh(p.geometry, p.material);
    mesh.scale.set(w, h, L);
    mesh.position.set(0, bottom, rear - L / 2);
    mesh.castShadow = true;
    g.add(mesh);
  }
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, bottom + fit.axis * h, rear - L - 0.02);
  const mag = new THREE.Object3D(); // el cargador va fundido en la malla
  const flash = muzzleFlash(muzzle);
  g.add(muzzle, mag, flash);
  g.userData = { muzzle, mag, flash, fore: rear - fit.fore * L, flashT: 0 };
  return g;
}

export function makeGun(kind, accent, assets = null) {
  const fromModel = modelGun(kind, assets);
  if (fromModel) return fromModel;
  const g = new THREE.Group();
  const dark = mat(0x3b3646, { metalness: 0.5, roughness: 0.4 });
  const mid = mat(0x7d7690, { metalness: 0.45, roughness: 0.45 });
  const acc = mat(accent, { emissive: accent, emissiveIntensity: 0.4 });
  const muzzle = new THREE.Object3D();
  let mag, fore;
  const barrel = (r, len, y, z) => {
    const b = part(new THREE.CylinderGeometry(r, r, len, 8), dark, 0, y, z);
    b.rotation.x = Math.PI / 2;
    g.add(b);
  };
  if (kind === 'rifle') {
    g.add(part(box(0.06, 0.1, 0.44), mid, 0, 0.03, -0.12));
    g.add(part(box(0.05, 0.065, 0.26), dark, 0, 0.035, -0.45));
    barrel(0.014, 0.2, 0.04, -0.66);
    g.add(part(box(0.045, 0.09, 0.2), dark, 0, 0.0, 0.2));
    g.add(part(box(0.04, 0.12, 0.05), dark, 0, -0.07, 0.02));
    g.add(part(box(0.02, 0.03, 0.12), acc, 0, 0.1, -0.1));
    mag = part(box(0.035, 0.16, 0.07), acc, 0, -0.1, -0.15);
    mag.rotation.x = 0.2;
    muzzle.position.set(0, 0.04, -0.77);
    fore = -0.42;
  } else if (kind === 'shotgun') {
    g.add(part(box(0.065, 0.1, 0.36), mid, 0, 0.03, -0.08));
    barrel(0.022, 0.5, 0.055, -0.5);
    barrel(0.016, 0.4, 0.01, -0.45);
    g.add(part(box(0.07, 0.06, 0.16), acc, 0, 0.0, -0.42));
    g.add(part(box(0.045, 0.1, 0.24), dark, 0, -0.01, 0.2));
    g.add(part(box(0.04, 0.11, 0.05), dark, 0, -0.07, 0.04));
    mag = part(box(0.05, 0.03, 0.14), acc, 0, -0.03, -0.12);
    muzzle.position.set(0, 0.055, -0.77);
    fore = -0.42;
  } else {
    g.add(part(box(0.06, 0.12, 0.3), mid, 0, 0.03, -0.08));
    barrel(0.016, 0.14, 0.05, -0.3);
    g.add(part(box(0.05, 0.05, 0.1), dark, 0, 0.0, -0.27));
    g.add(part(box(0.04, 0.1, 0.05), dark, 0, -0.07, 0.04));
    g.add(part(box(0.03, 0.05, 0.14), dark, 0, 0.03, 0.14));
    g.add(part(box(0.02, 0.025, 0.1), acc, 0, 0.105, -0.06));
    mag = part(box(0.032, 0.2, 0.05), acc, 0, -0.12, -0.12);
    muzzle.position.set(0, 0.05, -0.38);
    fore = -0.25;
  }
  g.add(mag, muzzle);
  const flash = muzzleFlash(muzzle);
  g.add(flash);
  g.userData = { muzzle, mag, flash, fore, flashT: 0 };
  return g;
}

// --- Personaje ---------------------------------------------------------------
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3(), _d = new THREE.Vector3();
const SHOULDER_R = new THREE.Vector3(0.26, 0.5, 0), SHOULDER_L = new THREE.Vector3(-0.26, 0.5, 0);
const POLE_R = new THREE.Vector3(0.7, -1, 0.35), POLE_L = new THREE.Vector3(-0.7, -1, 0.35);
const BELT = new THREE.Vector3(-0.14, 0.02, -0.16), REST_L = new THREE.Vector3(-0.32, 0.0, -0.1);

export class Character {
  constructor({ body = 0x2f2b3c, accent = 0x2de2c8, visor = 0xa8fff2, assets = null } = {}) {
    this.assets = assets;
    const root = this.root = new THREE.Group();
    const mBody = mat(body), mAcc = mat(accent), mDark = mat(0x15212d);
    const mSteel = mat(0x5c7784), mBlack = mat(0x08121c);
    const mTrim = mat(new THREE.Color(body).lerp(new THREE.Color(accent), 0.24));
    const mVisor = mat(visor), mGlow = mat(accent);
    const surface = mat(0xffffff, { vertexColors: true, metalness: 0.42, roughness: 0.43 });
    const glow = new THREE.MeshBasicMaterial({ color: 0xffffff, vertexColors: true, toneMapped: false });
    this.accent = accent;
    const assemblies = [];
    const rig = () => { const g = new THREE.Group(); assemblies.push(g); return g; };
    const plate = (g, w, h, d, material, x = 0, y = 0, z = 0, rz = 0) => {
      const m = part(armor(w, h, d), material, x, y, z);
      m.rotation.z = rz;
      g.add(m);
      return m;
    };
    const light = (g, w, h, d, material, x, y, z, rz = 0) => {
      const m = plate(g, w, h, d, material, x, y, z, rz);
      m.userData.luminous = true;
      return m;
    };
    const axle = (g, radius, length, material, x, y, z, axis = 'x') => {
      const m = part(cylinder(radius, length), material, x, y, z);
      if (axis === 'x') m.rotation.z = Math.PI / 2;
      if (axis === 'z') m.rotation.x = Math.PI / 2;
      g.add(m);
      return m;
    };

    this.pelvis = new THREE.Group();
    root.add(this.pelvis);
    this.lower = rig();
    this.pelvis.add(this.lower);
    plate(this.lower, 0.34, 0.15, 0.23, mDark, 0, 0.025);
    plate(this.lower, 0.19, 0.12, 0.04, mSteel, 0, 0.035, -0.13);
    light(this.lower, 0.065, 0.025, 0.012, mGlow, 0, 0.05, -0.155);
    for (const side of [-1, 1]) {
      plate(this.lower, 0.10, 0.16, 0.23, mBody, side * 0.17, -0.025, 0, side * -0.15);
    }

    const mkLeg = (side) => {
      const leg = rig();
      leg.position.set(0.115 * side, 0, 0);
      leg.add(part(cylinder(0.047, THIGH - 0.02), mSteel, 0, -THIGH / 2));
      leg.add(part(joint(0.071), mDark));
      plate(leg, 0.164, 0.30, 0.175, mBody, 0, -0.205, -0.014);
      plate(leg, 0.055, 0.215, 0.017, mTrim, side * 0.053, -0.2, -0.109);
      plate(leg, 0.08, 0.22, 0.045, mDark, 0, -0.21, 0.088);
      const shin = rig();
      shin.position.y = -THIGH;
      axle(shin, 0.064, 0.17, mDark, 0, 0, 0);
      axle(shin, 0.033, 0.177, mSteel, 0, 0, 0);
      plate(shin, 0.155, 0.12, 0.085, mAcc, 0, -0.008, -0.066);
      shin.add(part(cylinder(0.039, SHIN - 0.09), mSteel, 0, -0.23, 0.035));
      plate(shin, 0.145, 0.31, 0.15, mBody, 0, -0.235, -0.018);
      plate(shin, 0.067, 0.21, 0.025, mTrim, 0, -0.225, -0.1);
      light(shin, 0.018, 0.13, 0.012, mGlow, side * 0.05, -0.18, -0.1);
      plate(shin, 0.155, 0.09, 0.275, mDark, 0, -SHIN + 0.047, -0.053);
      plate(shin, 0.15, 0.065, 0.16, mBody, 0, -SHIN + 0.084, -0.091);
      plate(shin, 0.16, 0.028, 0.29, mBlack, 0, -SHIN + 0.014, -0.053);
      leg.add(shin);
      this.lower.add(leg);
      return { leg, shin };
    };
    this.legL = mkLeg(-1);
    this.legR = mkLeg(1);

    const spine = this.spine = rig();
    spine.position.y = 0.1;
    this.pelvis.add(spine);
    plate(spine, 0.29, 0.40, 0.205, mDark, 0, 0.285);
    for (let i = 0; i < 3; i++) {
      plate(spine, 0.27 - i * 0.016, 0.052, 0.048, mSteel, 0, 0.11 + i * 0.068, -0.108);
    }
    // Pectorales inclinados, collar separado y núcleo encastrado.
    for (const side of [-1, 1]) {
      plate(spine, 0.22, 0.25, 0.13, mBody, side * 0.112, 0.398, -0.095, side * -0.12);
      plate(spine, 0.115, 0.055, 0.035, mTrim, side * 0.12, 0.49, -0.17, side * -0.13);
      light(spine, 0.075, 0.016, 0.012, mGlow, side * 0.128, 0.427, -0.174, side * -0.15);
      plate(spine, 0.055, 0.20, 0.20, mTrim, side * 0.18, 0.28, 0.02, side * 0.12);
    }
    plate(spine, 0.10, 0.14, 0.035, mBlack, 0, 0.36, -0.166);
    light(spine, 0.045, 0.086, 0.016, mVisor, 0, 0.365, -0.191);
    plate(spine, 0.34, 0.055, 0.21, mSteel, 0, 0.545);
    axle(spine, 0.055, 0.11, mDark, 0, 0.58, 0, 'y');

    // Reactor dorsal: marco, núcleo vertical y dos disipadores luminosos.
    plate(spine, 0.30, 0.34, 0.115, mDark, 0, 0.34, 0.151);
    plate(spine, 0.18, 0.30, 0.055, mBody, 0, 0.35, 0.223);
    plate(spine, 0.075, 0.22, 0.025, mBlack, 0, 0.35, 0.26);
    light(spine, 0.033, 0.17, 0.012, mGlow, 0, 0.35, 0.279);
    for (const side of [-1, 1]) {
      plate(spine, 0.065, 0.24, 0.11, mTrim, side * 0.126, 0.36, 0.205);
      light(spine, 0.025, 0.11, 0.014, mGlow, side * 0.126, 0.375, 0.268);
      for (let i = 0; i < 3; i++) {
        plate(spine, 0.07, 0.018, 0.018, mBlack, side * 0.126, 0.27 + i * 0.034, 0.267);
      }
    }

    const head = this.head = rig();
    head.position.y = 0.66;
    plate(head, 0.27, 0.27, 0.278, mBody, 0, 0.007);
    plate(head, 0.235, 0.094, 0.045, mBlack, 0, 0.025, -0.139);
    // Visor frontal ancho con extensiones laterales y ceja protectora.
    light(head, 0.204, 0.036, 0.016, mVisor, 0, 0.032, -0.168);
    plate(head, 0.25, 0.036, 0.045, mTrim, 0, 0.088, -0.132);
    plate(head, 0.15, 0.062, 0.048, mDark, 0, -0.077, -0.132);
    plate(head, 0.05, 0.04, 0.025, mSteel, 0, -0.061, -0.166);
    plate(head, 0.053, 0.025, 0.21, mTrim, 0, 0.146, 0.007);
    for (const side of [-1, 1]) {
      axle(head, 0.054, 0.025, mDark, side * 0.139, 0.012, 0.022);
      axle(head, 0.031, 0.03, mSteel, side * 0.143, 0.012, 0.022);
      light(head, 0.016, 0.028, 0.092, mGlow, side * 0.137, 0.037, -0.073);
    }
    light(head, 0.064, 0.019, 0.012, mGlow, 0, 0.025, 0.153);
    spine.add(head);

    const mkArm = (side) => {
      const upper = rig(), lower = rig();
      upper.add(part(joint(0.061), mDark));
      upper.add(part(cylinder(0.036, L1 - 0.03), mSteel, 0, -L1 / 2));
      plate(upper, 0.18, 0.145, 0.20, mBody, side * 0.018, -0.025, 0, side * 0.12);
      plate(upper, 0.035, 0.10, 0.15, mAcc, side * 0.099, -0.027, 0);
      light(upper, 0.012, 0.045, 0.09, mGlow, side * 0.121, -0.02, 0);
      plate(upper, 0.108, 0.15, 0.13, mTrim, 0, -0.20, -0.013);
      axle(lower, 0.05, 0.12, mDark, 0, 0, 0);
      plate(lower, 0.132, 0.23, 0.15, mBody, 0, -0.145, -0.012);
      plate(lower, 0.075, 0.15, 0.025, mAcc, 0, -0.14, -0.093);
      light(lower, 0.055, 0.02, 0.011, mGlow, 0, -0.112, -0.109);
      plate(lower, 0.11, 0.035, 0.12, mSteel, 0, -L2 + 0.025);
      plate(lower, 0.10, 0.085, 0.12, mDark, 0, -L2 - 0.025, -0.012);
      plate(lower, 0.078, 0.037, 0.021, mSteel, 0, -L2 - 0.016, -0.077);
      spine.add(upper, lower);
      return { upper, lower };
    };
    this.armL = mkArm(-1);
    this.armR = mkArm(1);
    for (const assembly of assemblies) bakeAssembly(assembly, surface, glow);
    // Los materiales usados como paleta ya están codificados en los vértices.
    for (const material of [mBody, mAcc, mSteel, mBlack, mTrim, mVisor, mGlow]) material.dispose();

    this.gunHolder = new THREE.Group();
    spine.add(this.gunHolder);
    this.guns = {};
    this.gun = null;

    // Emisor de luz sólida para el modo construcción
    this.tool = modelGun('tool', assets);
    if (!this.tool) {
      this.tool = new THREE.Group();
      this.tool.add(part(box(0.07, 0.07, 0.18), mDark, 0, 0, -0.05));
      this.tool.add(part(box(0.11, 0.11, 0.03), new THREE.MeshStandardMaterial({ color: 0x9b6bff, emissive: 0x9b6bff, emissiveIntensity: 2 }), 0, 0, -0.15));
    }
    this.tool.visible = false;
    this.gunHolder.add(this.tool);

    this.phase = 0;
    this.cw = 0; this.sw = 0; this.aw = 0; this.run = 0; this.sprintW = 0; this.twist = 0; this.buildW = 0;
    this.stepped = false; // se activa el fotograma en que un pie toca el suelo
  }

  addGun(kind) {
    const g = makeGun(kind, this.accent, this.assets);
    g.visible = false;
    this.guns[kind] = g;
    this.gunHolder.add(g);
    return g;
  }

  setGun(kind) {
    for (const k in this.guns) this.guns[k].visible = k === kind;
    this.gun = this.guns[kind];
  }

  flash() {
    if (!this.gun) return;
    const u = this.gun.userData;
    u.flash.visible = true;
    u.flash.rotation.y = Math.random() * 6.28;
    u.flashT = 0.045;
  }

  // s: { speed, fwd, strafe, grounded, crouch, slide, sprint, pitch, kick, reloadT, build }
  update(dt, s) {
    const cw = this.cw = damp(this.cw, s.crouch && !s.slide ? 1 : 0, 14, dt);
    const sw = this.sw = damp(this.sw, s.slide ? 1 : 0, 16, dt);
    const aw = this.aw = damp(this.aw, s.grounded ? 0 : 1, 12, dt);
    const moving = s.speed > 0.4;
    const run = this.run = damp(this.run, moving ? clamp(s.speed / 8.4, 0.25, 1.15) : 0, 12, dt);
    const back = s.fwd < -0.3;

    const prev = Math.sin(this.phase);
    if (moving && !s.slide) this.phase += dt * (3.5 + s.speed * 1.5) * (back ? -1 : 1);
    const p = this.phase;
    this.stepped = s.grounded && moving && !s.slide && (prev * Math.sin(p) < 0);

    // Las piernas giran hacia la dirección de avance.
    let tw = 0;
    if (moving) tw = back ? Math.atan2(s.strafe, -s.fwd) : Math.atan2(-s.strafe, Math.max(s.fwd, 0.001));
    this.twist = damp(this.twist, clamp(tw, -1.0, 1.0), 12, dt);
    this.lower.rotation.y = this.twist;

    const A = 0.85 * run * (1 - 0.45 * cw);
    let thL = Math.sin(p) * A, thR = -Math.sin(p) * A;
    let knL = 0.12 * run + 1.25 * A * Math.max(0, Math.cos(p));
    let knR = 0.12 * run + 1.25 * A * Math.max(0, -Math.cos(p));
    thL += cw; thR += cw; knL += 1.7 * cw; knR += 1.7 * cw;            // agachado
    thL = lerp(thL, 0.7, aw); knL = lerp(knL, 1.1, aw);                // en el aire
    thR = lerp(thR, -0.1, aw); knR = lerp(knR, 0.55, aw);
    thL = lerp(thL, 0.7, sw); knL = lerp(knL, 2.0, sw);                // deslizándose
    thR = lerp(thR, 0.95, sw); knR = lerp(knR, 0.15, sw);
    this.legL.leg.rotation.x = thL; this.legL.shin.rotation.x = -knL;
    this.legR.leg.rotation.x = thR; this.legR.shin.rotation.x = -knR;

    let hipY = HIP_Y - 0.33 * cw - Math.abs(Math.cos(p)) * 0.04 * run;
    hipY = lerp(hipY, 0.34, sw);
    this.pelvis.position.y = hipY;
    this.pelvis.rotation.x = lerp(-0.1 * run * (s.sprint ? 1.8 : 1), 0.55, sw);
    this.pelvis.rotation.z = Math.sin(p) * 0.04 * run;
    this.spine.rotation.x = s.pitch * 0.55 - 0.3 * cw - 0.2 * sw;
    this.spine.rotation.y = -this.twist * 0.25;
    this.head.rotation.x = s.pitch * 0.35;

    // Arma y brazos (cinemática inversa de dos huesos).
    const gh = this.gunHolder;
    const bw = this.buildW = damp(this.buildW, s.build ? 1 : 0, 16, dt);
    const sprintW = this.sprintW = damp(this.sprintW, s.sprint && s.kick < 0.05 && s.reloadT < 0 && !s.build ? 1 : 0, 10, dt);
    let gx = 0.15, gy = 0.36, gz = -0.3, rx = 0, ry = 0, rz = 0, hand = 0;
    ry += 0.75 * sprintW; rx -= 0.35 * sprintW; gx -= 0.05 * sprintW; gy -= 0.06 * sprintW;
    gz += 0.07 * s.kick; rx += 0.08 * s.kick;
    const gun = this.gun, ud = gun ? gun.userData : null;
    if (s.reloadT >= 0) {
      const t = clamp(s.reloadT, 0, 1), w = Math.sin(Math.PI * t);
      rz += 0.5 * w; rx += 0.35 * w; gy -= 0.04 * w;
      hand = clamp((t - 0.15) / 0.15, 0, 1) * clamp((0.75 - t) / 0.15, 0, 1);
      if (ud) ud.mag.visible = !(t > 0.25 && t < 0.62);
    } else if (ud) ud.mag.visible = true;
    gy += 0.02 * bw; gz -= 0.1 * bw;
    gh.position.set(gx, gy, gz);
    gh.rotation.set(rx, ry, rz);
    gh.updateMatrix();
    if (gun) gun.visible = !s.build;
    this.tool.visible = !!s.build;

    _a.set(0, -0.05, 0.03).applyMatrix4(gh.matrix);
    this.solveArm(this.armR, SHOULDER_R, _a, POLE_R);
    _b.set(0, 0.0, ud ? ud.fore : -0.3).applyMatrix4(gh.matrix);
    _b.lerp(BELT, hand).lerp(REST_L, Math.max(bw, sw * 0.8));
    this.solveArm(this.armL, SHOULDER_L, _b, POLE_L);

    if (ud && ud.flashT > 0) { ud.flashT -= dt; if (ud.flashT <= 0) ud.flash.visible = false; }
  }

  solveArm(arm, S, T, pole) {
    _c.subVectors(T, S);
    const dist = clamp(_c.length(), 0.08, L1 + L2 - 0.002);
    _c.normalize();
    const a = (L1 * L1 - L2 * L2 + dist * dist) / (2 * dist);
    const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));
    _d.copy(pole).addScaledVector(_c, -pole.dot(_c)).normalize();
    // codo
    const ex = S.x + _c.x * a + _d.x * h, ey = S.y + _c.y * a + _d.y * h, ez = S.z + _c.z * a + _d.z * h;
    const hx = S.x + _c.x * dist, hy = S.y + _c.y * dist, hz = S.z + _c.z * dist;
    arm.upper.position.copy(S);
    _d.set(ex - S.x, ey - S.y, ez - S.z).normalize();
    arm.upper.quaternion.setFromUnitVectors(DOWN, _d);
    arm.lower.position.set(ex, ey, ez);
    _d.set(hx - ex, hy - ey, hz - ez).normalize();
    arm.lower.quaternion.setFromUnitVectors(DOWN, _d);
  }

  muzzleWorld(out) {
    if (!this.gun) return out.copy(this.root.position).setY(this.root.position.y + 1.3);
    return this.gun.userData.muzzle.getWorldPosition(out);
  }
}

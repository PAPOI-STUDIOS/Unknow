// Construcción con placas de luz sólida: muros, suelos y rampas sobre una rejilla.
import * as THREE from 'three';
import { G, H, ARENA, DIRS } from './util.js';
import { rampHeight, RAMP_THICK } from './physics.js';

export const COST = 10;
const HP = { wall: 150, floor: 140, ramp: 140 };
const T = 0.2;                         // grosor de las placas
const LEN = Math.hypot(G, H);          // largo de la rampa
const SLOPE = Math.atan2(H, G);
const MAX_LEVEL = 10;
const heightKey = (y) => Math.round(y * 1000);
const baseHeight = (pl) => (pl.base || 0) + pl.l * H;

function panelTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#1c1136';
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = '#8f5cff';
  g.lineWidth = 3;
  // Celosía triangular
  const n = 4, s = 256 / n;
  g.globalAlpha = 0.55;
  for (let i = 0; i <= n; i++) {
    g.beginPath(); g.moveTo(0, i * s); g.lineTo(256, i * s); g.stroke();
  }
  for (let i = -n; i <= n; i++) {
    g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s + 256 / 2 * 1.0, 256); g.stroke();
    g.beginPath(); g.moveTo(i * s + 256 / 2, 0); g.lineTo(i * s, 256); g.stroke();
  }
  g.globalAlpha = 1;
  g.strokeStyle = '#e2ccff';
  g.lineWidth = 10;
  g.strokeRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class BuildSystem {
  constructor(game) {
    this.game = game;
    this.world = game.world;
    this.scene = game.scene;
    this.pieces = new Map();
    this.edges = new Map();
    this.anims = [];
    this.tex = panelTexture();
    this.baseMat = new THREE.MeshStandardMaterial({
      map: this.tex, emissiveMap: this.tex, emissive: 0xffffff, emissiveIntensity: 0.75,
      color: 0xffffff, roughness: 0.4, metalness: 0.1, transparent: true, opacity: 0.9,
    });
    this.geo = {
      wall: new THREE.BoxGeometry(G, H, T),
      floor: new THREE.BoxGeometry(G, T, G),
      ramp: new THREE.BoxGeometry(G, T, LEN),
    };
    this.ghostMat = new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.35, depthWrite: false });
    this.ghost = {};
    for (const k in this.geo) {
      const m = new THREE.Mesh(this.geo[k], this.ghostMat);
      m.visible = false;
      m.renderOrder = 2;
      this.scene.add(m);
      this.ghost[k] = m;
    }
  }

  // Coloca la malla de una pieza (o del fantasma) según su celda.
  poseMesh(mesh, pl) {
    mesh.rotation.set(0, 0, 0);
    const y = baseHeight(pl);
    if (pl.type === 'wall') {
      if (pl.orient === 'x') mesh.position.set((pl.i + 0.5) * G, y + H / 2, pl.j * G);
      else { mesh.position.set(pl.i * G, y + H / 2, (pl.j + 0.5) * G); mesh.rotation.y = Math.PI / 2; }
    } else if (pl.type === 'floor') {
      mesh.position.set((pl.i + 0.5) * G, y - T / 2, (pl.j + 0.5) * G);
    } else {
      const u = DIRS[pl.d];
      mesh.rotation.order = 'YXZ';
      mesh.rotation.set(-SLOPE, Math.atan2(u.x, u.z), 0);
      mesh.position.set((pl.i + 0.5) * G, y + H / 2 - (T / 2) / Math.cos(SLOPE), (pl.j + 0.5) * G);
    }
  }

  edgeKeys(pl) {
    const { i, j } = pl, y = heightKey(baseHeight(pl)), top = heightKey(baseHeight(pl) + H);
    if (pl.type === 'wall') return pl.orient === 'x' ? [`x:${i},${j},${y}`, `x:${i},${j},${top}`] : [`z:${i},${j},${y}`, `z:${i},${j},${top}`];
    if (pl.type === 'floor') return [`x:${i},${j},${y}`, `x:${i},${j + 1},${y}`, `z:${i},${j},${y}`, `z:${i + 1},${j},${y}`];
    switch (pl.d) {
      case 0: return [`z:${i},${j},${y}`, `z:${i + 1},${j},${top}`];
      case 2: return [`z:${i + 1},${j},${y}`, `z:${i},${j},${top}`];
      case 1: return [`x:${i},${j},${y}`, `x:${i},${j + 1},${top}`];
      default: return [`x:${i},${j + 1},${y}`, `x:${i},${j},${top}`];
    }
  }

  groundAt(x, z) { return this.world.groundHeight?.(x, z) ?? 0; }

  // Altura de apoyo fija alcanzable, sin tomar como cimentación otras placas.
  supportAt(x, z, ceiling) {
    let y = this.groundAt(x, z);
    for (const c of this.world.boxes) {
      if (!c.piece && c.max.y <= ceiling && c.max.y > y &&
          x >= c.min.x - 0.05 && x <= c.max.x + 0.05 && z >= c.min.z - 0.05 && z <= c.max.z + 0.05) y = c.max.y;
    }
    for (const rp of this.world.ramps) {
      if (!rp.solid || x < rp.x0 || x > rp.x1 || z < rp.z0 || z > rp.z1) continue;
      const h = rampHeight(rp, x, z);
      if (h <= ceiling && h > y) y = h;
    }
    return y;
  }

  // ¿El punto descansa sobre el suelo o sobre una estructura fija del mapa?
  restsAt(x, y, z) {
    if (this.world.isLand && !this.world.isLand(x, z, 0.2)) return false;
    if (Math.abs(y - this.groundAt(x, z)) < 0.3) return true;
    for (const c of this.world.boxes) {
      if (c.piece) continue;
      if (Math.abs(c.max.y - y) < 0.3 && x > c.min.x - 0.2 && x < c.max.x + 0.2 && z > c.min.z - 0.2 && z < c.max.z + 0.2) return true;
    }
    for (const rp of this.world.ramps) {
      if (rp.solid && x >= rp.x0 && x <= rp.x1 && z >= rp.z0 && z <= rp.z1 &&
          Math.abs(rampHeight(rp, x, z) - y) < 0.3) return true;
    }
    return false;
  }

  isAnchored(pl) {
    const { i, j } = pl, y = baseHeight(pl);
    if (pl.type === 'wall') {
      return pl.orient === 'x' ? this.restsAt((i + 0.5) * G, y, j * G) : this.restsAt(i * G, y, (j + 0.5) * G);
    }
    if (pl.type === 'floor') {
      return this.restsAt((i + 0.5) * G, y, j * G) || this.restsAt((i + 0.5) * G, y, (j + 1) * G) ||
        this.restsAt(i * G, y, (j + 0.5) * G) || this.restsAt((i + 1) * G, y, (j + 0.5) * G);
    }
    const u = DIRS[pl.d], cx = (i + 0.5) * G, cz = (j + 0.5) * G;
    for (const side of [-0.5, 0, 0.5]) {
      const ox = -u.z * G * side, oz = u.x * G * side;
      if (this.restsAt(cx - u.x * G / 2 + ox, y, cz - u.z * G / 2 + oz) ||
          this.restsAt(cx + u.x * G / 2 + ox, y + H, cz + u.z * G / 2 + oz)) return true;
    }
    return false;
  }

  // ¿La pieza atraviesa una estructura fija del mapa?
  blocked(pl) {
    const pts = [];
    const { i, j } = pl, y = baseHeight(pl);
    if (pl.type === 'wall') {
      for (const f of [0.25, 0.5, 0.75]) {
        if (pl.orient === 'x') pts.push([(i + f) * G, y + H / 2, j * G]);
        else pts.push([i * G, y + H / 2, (j + f) * G]);
      }
    } else if (pl.type === 'floor') {
      pts.push([(i + 0.5) * G, y - T / 2, (j + 0.5) * G], [(i + 0.25) * G, y - T / 2, (j + 0.25) * G], [(i + 0.75) * G, y - T / 2, (j + 0.75) * G]);
    } else {
      const u = DIRS[pl.d], cx = (i + 0.5) * G, cz = (j + 0.5) * G;
      for (const f of [-0.25, 0, 0.25]) pts.push([cx + u.x * G * f, y + (0.5 + f) * H + 0.15, cz + u.z * G * f]);
    }
    // La superficie de las placas debe quedar sobre el terreno. Se permite
    // enterrar unos centímetros el grosor de un suelo, no una pieza completa.
    for (const p of pts) {
      if (this.world.isLand && !this.world.isLand(p[0], p[2], 0.35)) return true;
      if (p[1] < this.groundAt(p[0], p[2]) - (pl.type === 'floor' ? T : 0.12)) return true;
    }
    const footprint = pl.type === 'wall'
      ? (pl.orient === 'x' ? [[i * G, j * G], [(i + 1) * G, j * G]] : [[i * G, j * G], [i * G, (j + 1) * G]])
      : [[i * G, j * G], [(i + 1) * G, j * G], [i * G, (j + 1) * G], [(i + 1) * G, (j + 1) * G]];
    for (const [px, pz] of footprint) {
      if (this.world.isLand && !this.world.isLand(px, pz, 0.35)) return true;
      let surface = y;
      if (pl.type === 'ramp') {
        const u = DIRS[pl.d];
        surface += (0.5 + ((px - (i + 0.5) * G) * u.x + (pz - (j + 0.5) * G) * u.z) / G) * H;
      }
      // Las paredes se cimentan en pendientes moderadas; una ladera no debe
      // atravesar toda su mitad inferior. Suelos/rampas mantienen la superficie libre.
      if (this.groundAt(px, pz) > surface + (pl.type === 'wall' ? 0.8 : 0.18)) return true;
    }
    for (const c of this.world.boxes) {
      if (c.piece) continue;
      for (const p of pts) {
        if (p[0] > c.min.x + 0.05 && p[0] < c.max.x - 0.05 && p[1] > c.min.y + 0.05 && p[1] < c.max.y - 0.05 && p[2] > c.min.z + 0.05 && p[2] < c.max.z - 0.05) return true;
      }
    }
    for (const rp of this.world.ramps) {
      if (!rp.solid) continue;
      for (const p of pts) {
        if (p[0] > rp.x0 && p[0] < rp.x1 && p[2] > rp.z0 && p[2] < rp.z1 && p[1] > rp.y0 && p[1] < rampHeight(rp, p[0], p[2]) - 0.2) return true;
      }
    }
    return false;
  }

  // Calcula dónde iría una pieza para alguien en (x, y, z) mirando con yaw/pitch.
  // `standRamp`: rampa sobre la que está apoyado, para encadenar subidas.
  computePlacement(type, x, y, z, yaw, pitch, standRamp) {
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    const ax = Math.abs(fx) > Math.abs(fz);
    const d = ax ? (fx > 0 ? 0 : 2) : (fz > 0 ? 1 : 3);
    const pl = { type, i: 0, j: 0, l: 0, base: 0, d, orient: 'x', key: '', valid: false };
    if (type === 'wall') {
      if (ax) {
        pl.orient = 'z';
        pl.i = fx > 0 ? Math.ceil((x + 0.5) / G) : Math.floor((x - 0.5) / G);
        pl.j = Math.floor((z + fz * 2) / G);
      } else {
        pl.j = fz > 0 ? Math.ceil((z + 0.5) / G) : Math.floor((z - 0.5) / G);
        pl.i = Math.floor((x + fx * 2) / G);
      }
    } else if (type === 'floor') {
      const reach = Math.abs(pitch) > 0.95 ? 0 : G * 0.6;
      pl.i = Math.floor((x + fx * reach) / G);
      pl.j = Math.floor((z + fz * reach) / G);
    } else {
      pl.i = Math.floor((x + (ax ? Math.sign(fx) * 2 : 0)) / G);
      pl.j = Math.floor((z + (ax ? 0 : Math.sign(fz) * 2)) / G);
    }

    // Cada cimentación tiene su propia cota. Al ampliar una estructura se
    // hereda su cota, y sus uniones se identifican por altura física, no por nivel.
    const cx = (pl.i + 0.5) * G, cz = (pl.j + 0.5) * G, u = DIRS[d];
    const footX = type === 'wall' && pl.orient === 'z' ? pl.i * G : type === 'ramp' ? cx - u.x * G / 2 : cx;
    const footZ = type === 'wall' && pl.orient === 'x' ? pl.j * G : type === 'ramp' ? cz - u.z * G / 2 : cz;
    let foundation = this.supportAt(footX, footZ, y + 0.65);
    if (type === 'ramp') {
      // El borde inferior completo queda por encima de la ladera lateral.
      for (const side of [-0.5, 0.5]) {
        foundation = Math.max(foundation, this.supportAt(footX - u.z * G * side, footZ + u.x * G * side, y + 0.65));
      }
    }
    const bases = [];
    if (standRamp?.piece) bases.push(standRamp.piece.base || 0);
    else if (standRamp?.solid) bases.push(standRamp.y0);
    for (const pc of this.pieces.values()) {
      if (Math.abs(pc.i - pl.i) <= 1 && Math.abs(pc.j - pl.j) <= 1) bases.push(pc.base || 0);
    }
    bases.push(foundation);
    const candidates = [...new Set(bases.map((v) => Math.round(v * 1000) / 1000))];
    const lim = ARENA / G;
    for (const base of candidates) {
      pl.base = base;
      const localY = y - base;
      if (type === 'wall') {
        pl.l = Math.max(0, Math.floor((localY + 0.4) / H));
        if (pitch > 0.6) pl.l++; else if (pitch < -0.8 && pl.l > 0) pl.l--;
      } else if (type === 'floor') {
        const lvl = Math.max(0, Math.round(localY / H));
        pl.l = lvl === 0 || pitch > 0.35 ? lvl + 1 : lvl;
      } else {
        pl.l = Math.max(0, Math.floor((localY + 0.75) / H));
        if (standRamp && standRamp.dir === d && (pl.i * G !== standRamp.x0 || pl.j * G !== standRamp.z0)) {
          pl.l = Math.round((standRamp.y0 + standRamp.rise - base) / H);
        }
      }
      const prefix = type === 'wall' ? `w:${pl.orient}` : type === 'floor' ? 'f' : 'r';
      pl.key = `${prefix}:${pl.i},${pl.j},${heightKey(baseHeight(pl))}`;
      pl.valid = !this.pieces.has(pl.key) && pl.l >= 0 && pl.l <= MAX_LEVEL &&
        baseHeight(pl) <= y + H + 0.8 &&
        pl.i >= -lim && pl.i < lim && pl.j >= -lim && pl.j < lim &&
        !this.blocked(pl) && (this.isAnchored(pl) || this.edgeKeys(pl).some((k) => this.edges.get(k)?.size));
      if (pl.valid) return pl;
    }
    return pl;
  }

  showGhost(pl, ok) {
    for (const k in this.ghost) this.ghost[k].visible = k === pl.type;
    this.poseMesh(this.ghost[pl.type], pl);
    this.ghostMat.color.setHex(ok ? 0xb48cff : 0xff4d4d);
    this.ghostMat.opacity = 0.3 + 0.08 * Math.sin(performance.now() * 0.008);
  }

  hideGhost() {
    for (const k in this.ghost) this.ghost[k].visible = false;
  }

  place(pl, owner) {
    if (this.pieces.has(pl.key)) return null;
    const { i, j } = pl, y = baseHeight(pl);
    const mesh = new THREE.Mesh(this.geo[pl.type], this.baseMat.clone());
    this.poseMesh(mesh, pl);
    mesh.castShadow = mesh.receiveShadow = true;
    this.scene.add(mesh);
    const piece = { ...pl, hp: HP[pl.type], maxHp: HP[pl.type], mesh, owner, collider: null, edgeList: this.edgeKeys(pl), anchored: this.isAnchored(pl), flash: 0, spawn: 0 };
    if (pl.type === 'wall') {
      piece.collider = pl.orient === 'x'
        ? this.world.addBox(i * G, y, j * G - T / 2, (i + 1) * G, y + H, j * G + T / 2, { piece })
        : this.world.addBox(i * G - T / 2, y, j * G, i * G + T / 2, y + H, (j + 1) * G, { piece });
    } else if (pl.type === 'floor') {
      piece.collider = this.world.addBox(i * G, y - T, j * G, (i + 1) * G, y, (j + 1) * G, { piece });
    } else {
      const rp = piece.collider = this.world.addRamp(i * G, j * G, (i + 1) * G, (j + 1) * G, y, H, pl.d, { piece });
      // Quien quede debajo de la superficie sube encima.
      for (const a of this.game.actors) {
        if (!a.alive) continue;
        const b = a.body;
        if (b.x < rp.x0 || b.x > rp.x1 || b.z < rp.z0 || b.z > rp.z1) continue;
        const hs = rampHeight(rp, b.x, b.z);
        if (b.y < hs && b.y + b.h > hs - RAMP_THICK) { b.y = hs; b.vy = 0; }
      }
    }
    this.pieces.set(pl.key, piece);
    for (const k of piece.edgeList) {
      let s = this.edges.get(k);
      if (!s) this.edges.set(k, (s = new Set()));
      s.add(piece);
    }
    mesh.scale.setScalar(0.6);
    this.anims.push(piece);
    this.game.onBuilt(piece);
    return piece;
  }

  damage(piece, amount) {
    if (piece.hp <= 0) return;
    piece.hp -= amount;
    piece.flash = 1;
    if (!this.anims.includes(piece)) this.anims.push(piece);
    if (piece.hp <= 0) { this.remove(piece); this.collapse(); }
    else piece.mesh.material.opacity = 0.45 + 0.45 * (piece.hp / piece.maxHp);
  }

  remove(piece) {
    piece.hp = 0;
    this.pieces.delete(piece.key);
    for (const k of piece.edgeList) this.edges.get(k)?.delete(piece);
    this.world.remove(piece.collider);
    this.scene.remove(piece.mesh);
    piece.mesh.material.dispose();
    const p = piece.mesh.position;
    for (let n = 0; n < 14; n++) {
      this.game.fx.spawn(p.x + (Math.random() - 0.5) * G * 0.8, p.y + (Math.random() - 0.5) * H * 0.7, p.z + (Math.random() - 0.5) * G * 0.8,
        (Math.random() - 0.5) * 4, Math.random() * 3, (Math.random() - 0.5) * 4, n % 2 ? 0xb48cff : 0x6a35ff, 0.1 + Math.random() * 0.14, 0.5 + Math.random() * 0.5);
    }
    this.game.onBroken(piece);
  }

  // Derriba las piezas que ya no están unidas a nada apoyado.
  collapse() {
    const seen = new Set(), stack = [];
    for (const p of this.pieces.values()) if (p.anchored) { seen.add(p); stack.push(p); }
    while (stack.length) {
      const p = stack.pop();
      for (const k of p.edgeList) {
        const s = this.edges.get(k);
        if (!s) continue;
        for (const q of s) if (!seen.has(q)) { seen.add(q); stack.push(q); }
      }
    }
    for (const p of [...this.pieces.values()]) if (!seen.has(p)) this.remove(p);
  }

  update(dt) {
    for (let n = this.anims.length - 1; n >= 0; n--) {
      const p = this.anims[n];
      if (p.hp <= 0) { this.anims.splice(n, 1); continue; }
      p.spawn = Math.min(1, p.spawn + dt * 9);
      p.flash = Math.max(0, p.flash - dt * 6);
      p.mesh.scale.setScalar(0.6 + 0.4 * p.spawn);
      p.mesh.material.emissiveIntensity = 0.75 + (1 - p.spawn) * 1.5 + p.flash * 1.2;
      if (p.spawn >= 1 && p.flash <= 0) this.anims.splice(n, 1);
    }
  }
}

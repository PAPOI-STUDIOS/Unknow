// Sonido. Los disparos se sintetizan con WebAudio; todo lo demás son muestras
// generadas con Higgsfield (assets/audio), recortadas y niveladas al cargar.

// Volumen relativo de cada muestra una vez normalizada.
const GAIN = {
  step: 0.42, jump: 0.4, land: 0.6, slide: 0.5, reload_out: 0.6, reload_in: 0.65, shell_insert: 0.55,
  dry_fire: 0.5, weapon_switch: 0.45, hit_body: 0.5, hit_head: 0.6, kill: 0.75, hurt_1: 0.7, hurt_2: 0.7,
  shield_break: 0.7, low_health: 0.4, impact_dirt: 0.5, impact_metal: 0.45, impact_energy: 0.5, whiz: 0.55,
  build_place: 0.5, build_break: 0.6, pickup_ammo: 0.55, pickup_shield: 0.5, pickup_heal: 0.5, pickup_mats: 0.5,
  pod_open: 0.65, zone_alarm: 0.5, zone_burn: 0.45, win: 0.8, lose: 0.8, ui_click: 0.4, match_start: 0.7,
};
const AMBIENT = { ocean: 0.5, forest: 0.4, meadow: 0.3, snow: 0.45, desert: 0.35, compound: 0.22 };
const PICKUP = { ammo: 'pickup_ammo', shield: 'pickup_shield', med: 'pickup_heal', mats: 'pickup_mats' };

// Recorte de cada muestra. `onset`: fracción del pico a partir de la cual empieza
// (alta = arranca justo en el golpe; baja = conserva la entrada gradual).
// `max`: duración máxima en segundos. `last`: quedarse solo con el final.
const SWELL = { onset: 0.03 };
const TRIM = {
  jump: { max: 0.35 }, land: { max: 0.45 }, slide: SWELL, dry_fire: { max: 0.25 }, shell_insert: { max: 0.3 },
  reload_out: { max: 0.6 }, reload_in: { onset: 0.1, max: 0.8 }, weapon_switch: { max: 0.5 },
  hit_body: { max: 0.4 }, hit_head: { max: 0.5 }, hurt_1: { max: 0.5 }, hurt_2: { max: 0.5 },
  impact_dirt: { max: 0.45 }, impact_metal: { max: 0.5 }, impact_energy: { max: 0.55 }, whiz: { onset: 0.05, max: 0.6 },
  build_place: { onset: 0.03, last: 0.4 }, build_break: { max: 1.3 }, kill: SWELL, shield_break: { onset: 0.08 },
  pickup_ammo: { max: 0.6 }, pickup_shield: { onset: 0.05, max: 0.8 }, pickup_heal: { onset: 0.05, max: 0.9 }, pickup_mats: { max: 0.8 },
  pod_open: { onset: 0.1 }, zone_alarm: SWELL, zone_burn: { onset: 0.03, max: 1.2 }, low_health: { onset: 0.05 },
  win: SWELL, lose: SWELL, match_start: SWELL, ui_click: { max: 0.2 },
};

// Pico absoluto por muestra entre todos los canales.
function envelope(buffer) {
  const env = new Float32Array(buffer.length);
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const d = buffer.getChannelData(c);
    for (let i = 0; i < d.length; i++) { const v = Math.abs(d[i]); if (v > env[i]) env[i] = v; }
  }
  return env;
}

// Copia [start, end) a un búfer nuevo, nivelado y con fundidos cortos.
function cut(ctx, buffer, start, end, fadeIn, fadeOut, level = 0.9) {
  const rate = buffer.sampleRate, n = Math.max(1, end - start);
  const out = ctx.createBuffer(buffer.numberOfChannels, n, rate);
  let peak = 0;
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const d = buffer.getChannelData(c);
    for (let i = start; i < end; i++) { const v = Math.abs(d[i]); if (v > peak) peak = v; }
  }
  // Algunas muestras llegan grabadas muy bajas: se suben hasta 60 veces.
  const gain = peak > 0.001 ? Math.min(60, level / peak) : 1;
  const fi = Math.min(n, Math.floor(fadeIn * rate)), fo = Math.min(n, Math.floor(fadeOut * rate));
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const src = buffer.getChannelData(c), dst = out.getChannelData(c);
    for (let i = 0; i < n; i++) {
      let g = gain;
      if (i < fi) g *= i / fi;
      if (i >= n - fo) g *= (n - i) / fo;
      dst[i] = src[start + i] * g;
    }
  }
  return out;
}

// Quita el silencio inicial (para que el sonido responda al instante) y la cola.
export function trimmed(ctx, buffer, { onset = 0.2, max = 0, last = 0 } = {}) {
  const env = envelope(buffer), rate = buffer.sampleRate;
  let peak = 0;
  for (let i = 0; i < env.length; i++) if (env[i] > peak) peak = env[i];
  if (peak < 0.001) return buffer;
  let start = 0, end = env.length - 1;
  while (start < env.length && env[start] < peak * onset) start++;
  while (end > start && env[end] < peak * 0.02) end--;
  start = Math.max(0, start - Math.floor(0.006 * rate));
  end = Math.min(env.length, end + Math.floor(0.05 * rate));
  if (last) start = Math.max(start, end - Math.floor(last * rate));
  if (max) end = Math.min(end, start + Math.floor(max * rate));
  return cut(ctx, buffer, start, end, 0.002, max || last ? 0.08 : 0.03);
}

// Alternativa cuando los pasos no están bien separados: una ventana corta
// alrededor de cada máximo de energía, nivelada por separado.
function windows(ctx, buffer, count = 4) {
  const env = envelope(buffer), rate = buffer.sampleRate, hop = Math.floor(0.02 * rate);
  const frames = [];
  for (let i = 0; i + hop <= env.length; i += hop) {
    let e = 0;
    for (let j = i; j < i + hop; j++) e += env[j] * env[j];
    frames.push(e);
  }
  const out = [], taken = [];
  for (let n = 0; n < count; n++) {
    let best = -1;
    for (let f = 0; f < frames.length; f++) {
      if (taken.some((t) => Math.abs(t - f) < 15)) continue; // 0,3 s de separación
      if (best < 0 || frames[f] > frames[best]) best = f;
    }
    if (best < 0 || frames[best] <= 0) break;
    taken.push(best);
    const a = Math.max(0, (best - 2) * hop), b = Math.min(env.length, a + Math.floor(0.3 * rate));
    out.push(cut(ctx, buffer, a, b, 0.004, 0.06, 0.8));
  }
  return out;
}

// Separa una grabación de varios pasos en golpes individuales.
export function slices(ctx, buffer) {
  const env = envelope(buffer), rate = buffer.sampleRate;
  const win = Math.floor(0.008 * rate), smooth = new Float32Array(env.length);
  let peak = 0;
  for (let i = 0, run = 0; i < env.length; i++) { // media móvil de 8 ms
    run += env[i] - (i >= win ? env[i - win] : 0);
    smooth[i] = run / win;
    if (smooth[i] > peak) peak = smooth[i];
  }
  if (peak < 0.0005) return [];
  const on = peak * 0.3, off = peak * 0.08, gap = Math.floor(0.07 * rate);
  const out = [];
  let start = -1, quiet = 0;
  for (let i = 0; i <= smooth.length; i++) {
    const v = i < smooth.length ? smooth[i] : 0;
    if (start < 0) { if (v > on) { start = i; quiet = 0; } continue; }
    quiet = v < off ? quiet + 1 : 0;
    if (quiet >= gap || i === smooth.length) {
      const a = Math.max(0, start - Math.floor(0.012 * rate));
      const b = Math.min(env.length, Math.min(i - quiet + Math.floor(0.06 * rate), a + Math.floor(0.45 * rate)));
      if (b - a > 0.04 * rate) out.push(cut(ctx, buffer, a, b, 0.003, 0.04, 0.8));
      start = -1;
    }
  }
  return out;
}

// Funde el final con el principio para que el bucle no tenga salto.
export function loopable(ctx, buffer, fade = 1.2) {
  const rate = buffer.sampleRate, f = Math.min(Math.floor(fade * rate), Math.floor(buffer.length / 3));
  const n = buffer.length - f, out = ctx.createBuffer(buffer.numberOfChannels, n, rate);
  let energy = 0;
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const src = buffer.getChannelData(c), dst = out.getChannelData(c);
    for (let i = 0; i < n; i++) {
      let v = src[i];
      if (i < f) { const t = i / f; v = v * Math.sqrt(t) + src[n + i] * Math.sqrt(1 - t); }
      dst[i] = v;
      energy += v * v;
    }
  }
  // Se nivela por volumen medio, no por pico: un chasquido aislado en la
  // grabación dejaría el resto inaudible. Lo que sobresale se recorta.
  const rms = Math.sqrt(energy / (n * out.numberOfChannels));
  const gain = rms > 0.0002 ? Math.min(80, 0.11 / rms) : 1, limit = 0.6;
  for (let c = 0; c < out.numberOfChannels; c++) {
    const d = out.getChannelData(c);
    for (let i = 0; i < n; i++) d[i] = Math.max(-limit, Math.min(limit, d[i] * gain));
  }
  return out;
}

export class Sfx {
  constructor() {
    this.ctx = null;
    this.raw = {};       // nombre → ArrayBuffer (mp3) aún sin decodificar
    this.buf = {};       // nombre → AudioBuffer
    this.sets = {};      // nombre → variantes (pasos)
    this.loops = {};     // ambiente en reproducción
    this.last = {};      // última vez que sonó cada cosa (para no saturar)
    this.lastPick = {};
    this.decoding = null;
    this.ambientTarget = null;
  }

  setSources(raw) { this.raw = raw || {}; }

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.45;
      this.master.connect(this.ctx.destination);
      this.samples = this.ctx.createGain();
      this.samples.gain.value = 1.7;
      this.samples.connect(this.master);
      this.ambientBus = this.ctx.createGain();
      this.ambientBus.gain.value = 1.2;
      this.ambientBus.connect(this.master);
      const len = this.ctx.sampleRate;
      this.noiseBuf = this.ctx.createBuffer(1, len, len);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    if (!this.decoding) this.decoding = this.decodeAll();
  }

  async decodeAll() {
    for (const [name, data] of Object.entries(this.raw)) {
      try {
        const audio = await this.ctx.decodeAudioData(data.slice(0));
        if (name.startsWith('step_')) {
          const parts = slices(this.ctx, audio);
          this.sets[name] = parts.length >= 3 ? parts : windows(this.ctx, audio);
        } else if (name.startsWith('amb_')) {
          this.buf[name] = loopable(this.ctx, audio);
          if (this.ambientTarget) this.ambience(this.ambientTarget);
        } else this.buf[name] = trimmed(this.ctx, audio, TRIM[name]);
      } catch (error) {
        console.warn(`No se pudo decodificar el sonido ${name}:`, error);
      }
    }
  }

  // ¿Ha pasado `seconds` desde la última vez? Evita ráfagas del mismo sonido.
  due(key, seconds) {
    const now = this.ctx ? this.ctx.currentTime : 0;
    if (now - (this.last[key] ?? -99) < seconds) return false;
    this.last[key] = now;
    return true;
  }

  play(name, vol = 1, { rate = 1, jitter = 0.05, delay = 0, gain = GAIN[name] ?? 1 } = {}) {
    if (!this.ctx || vol <= 0.004) return;
    let buffer = this.buf[name];
    const set = this.sets[name];
    if (set) { // variante distinta de la anterior
      let i = Math.floor(Math.random() * set.length);
      if (set.length > 1 && i === this.lastPick[name]) i = (i + 1) % set.length;
      this.lastPick[name] = i;
      buffer = set[i];
    }
    if (!buffer) return;
    const src = this.ctx.createBufferSource();
    src.buffer = buffer;
    src.playbackRate.value = rate * (1 + (Math.random() * 2 - 1) * jitter);
    const g = this.ctx.createGain();
    g.gain.value = vol * gain;
    src.connect(g).connect(this.samples);
    src.start(this.ctx.currentTime + delay);
  }

  // --- Disparos sintetizados (se conservan tal cual) ---
  noise(dur, freq, q, gain, type = 'lowpass', sweep = 0) {
    if (!this.ctx || gain <= 0.002) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loopStart = Math.random() * 0.5;
    const f = this.ctx.createBiquadFilter();
    f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(40, sweep), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random() * 0.5, dur + 0.02);
  }

  tone(f0, f1, dur, gain, type = 'sine', delay = 0) {
    if (!this.ctx || gain <= 0.002) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + dur + 0.02);
  }

  shot(kind, vol = 1) {
    if (kind === 'shotgun') { this.noise(0.32, 1400, 0.6, 0.9 * vol, 'lowpass', 200); this.tone(140, 45, 0.2, 0.7 * vol, 'triangle'); }
    else if (kind === 'smg') { this.noise(0.09, 3200, 0.8, 0.5 * vol, 'lowpass', 700); this.tone(320, 120, 0.06, 0.3 * vol, 'square'); }
    else { this.noise(0.14, 2400, 0.7, 0.65 * vol, 'lowpass', 400); this.tone(210, 70, 0.1, 0.45 * vol, 'triangle'); }
  }

  // --- Muestras ---
  step(surface = 'concrete', vol = 1) { this.play(`step_${surface}`, vol, { jitter: 0.1, gain: GAIN.step }); }
  jump() { this.play('jump'); }
  land(vol = 1) { this.play('land', vol); }
  slide() { this.play('slide'); }
  dry() { this.play('dry_fire'); }
  switchWeapon() { this.play('weapon_switch'); }
  reloadOut() { this.play('reload_out'); }
  reloadIn() { this.play('reload_in'); }
  shell() { this.play('shell_insert', 1, { jitter: 0.08 }); }
  hit(head) { if (this.due('hit', 0.04)) this.play(head ? 'hit_head' : 'hit_body'); }
  kill(vol = 1) { this.play('kill', vol); }
  hurt() { if (this.due('hurt', 0.12)) this.play(Math.random() < 0.5 ? 'hurt_1' : 'hurt_2'); }
  shieldBreak() { this.play('shield_break'); }
  lowHealth() { if (this.due('low', 2.6)) this.play('low_health', 1, { jitter: 0 }); }
  impact(kind, vol = 1) { if (this.due(`impact_${kind}`, 0.06)) this.play(`impact_${kind}`, vol, { jitter: 0.12 }); }
  whiz() { if (this.due('whiz', 0.18)) this.play('whiz', 1, { jitter: 0.15 }); }
  build() { if (this.due('build', 0.05)) this.play('build_place', 1, { jitter: 0.1 }); }
  breakPiece(vol = 1) { if (this.due('break', 0.08)) this.play('build_break', vol, { jitter: 0.1 }); }
  pickup(kind = 'ammo') { this.play(PICKUP[kind] || 'pickup_ammo'); }
  pod() { this.play('pod_open'); }
  zone() { this.play('zone_alarm', 1, { jitter: 0 }); }
  zoneBurn() { if (this.due('burn', 0.9)) this.play('zone_burn'); }
  win() { this.play('win', 1, { jitter: 0 }); }
  lose() { this.play('lose', 1, { jitter: 0 }); }
  ui() { this.play('ui_click', 1, { jitter: 0 }); }
  start() { this.play('match_start', 1, { jitter: 0 }); }

  // Mezcla de ambientes: { ocean, forest, meadow, snow, desert, compound } de 0 a 1,
  // o null para silenciarlos (menú y pausa).
  ambience(weights) {
    this.ambientTarget = weights;
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    for (const key in AMBIENT) {
      const buffer = this.buf[`amb_${key}`];
      if (!buffer) continue;
      let loop = this.loops[key];
      if (!loop) {
        const src = this.ctx.createBufferSource(), gain = this.ctx.createGain();
        src.buffer = buffer;
        src.loop = true;
        gain.gain.value = 0;
        src.connect(gain).connect(this.ambientBus);
        src.start(now, Math.random() * buffer.duration);
        loop = this.loops[key] = { src, gain };
      }
      loop.gain.gain.setTargetAtTime((weights?.[key] || 0) * AMBIENT[key], now, 0.7);
    }
  }
}

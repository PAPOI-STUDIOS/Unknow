// Isla de 336 m: la misma triangulación alimenta el dibujo, las pisadas y los rayos.
import * as THREE from 'three';

export const TERRAIN_EXTENT = 168;
export const TERRAIN_STEP = 2;
export const WATER_LEVEL = 0.5;
const CELLS = TERRAIN_EXTENT * 2 / TERRAIN_STEP;
const ROW = CELLS + 1;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const smooth = (lo, hi, x) => { const t = clamp((x - lo) / (hi - lo), 0, 1); return t * t * (3 - 2 * t); };
const mix = (a, b, t) => a + (b - a) * t;
const hill = (x, z, cx, cz, sx, sz) => Math.exp(-(((x - cx) / sx) ** 2 + ((z - cz) / sz) ** 2));

export function coastRadius(angle) {
  return 143 + 8 * Math.sin(angle * 3 + 0.4) + 6 * Math.cos(angle * 5 - 0.7) + 3 * Math.sin(angle * 9);
}

function rawHeight(x, z) {
  const inland = coastRadius(Math.atan2(z, x)) - Math.hypot(x, z);
  if (inland < -18) return -5;
  const shore = inland < 0 ? mix(-5, 0.8, smooth(-18, 0, inland)) : 0.8;
  const rolling = 4.5 + 1.1 * Math.sin(x * 0.043 + z * 0.021) * Math.cos(z * 0.049) +
    0.55 * Math.sin(x * 0.097 - z * 0.075);
  const relief = rolling + 19 * hill(x, z, 18, -96, 38, 32) + 15 * hill(x, z, 65, -80, 29, 27) +
    8 * hill(x, z, -87, -25, 34, 47) + 10 * hill(x, z, 91, 21, 28, 43) +
    5 * hill(x, z, -28, 95, 42, 27);
  const h = shore + relief * smooth(0, 25, inland);
  // El antiguo recinto ocupa exactamente 96 × 96 m; sus accesos siguen a escala humana.
  return mix(4, h, smooth(48, 80, Math.max(Math.abs(x), Math.abs(z))));
}

export const LANDMARK_PADS = [
  { name: 'forest', x: -82, z: -32, radius: 13 },
  { name: 'desert', x: 86, z: 26, radius: 15 },
  { name: 'observatory', x: 22, z: -94, radius: 14, y: 21.5 },
  { name: 'harbor', x: -20, z: 112, radius: 12 },
].map((p) => ({ ...p, y: p.y ?? Math.round(rawHeight(p.x, p.z) * 2) / 2 }));

function sampleHeight(x, z) {
  let h = rawHeight(x, z);
  for (const p of LANDMARK_PADS) {
    const d = Math.hypot(x - p.x, z - p.z);
    if (d < p.radius + 20) h = mix(p.y, h, smooth(p.radius, p.radius + 20, d));
  }
  // Un collado ancho conecta la plaza con el observatorio. Sin este perfil, la
  // suma de la ladera y la explanada produce un talud demasiado empinado a pie.
  const north = -z;
  if (north > 48 && north < 112) {
    const routeX = 22 * Math.min(north / 94, 1);
    const weight = (1 - smooth(13, 24, Math.abs(x - routeX))) * (1 - smooth(96, 112, north));
    const approach = mix(4, 21.5, smooth(48, 80, north));
    h = mix(h, approach, weight);
  }
  return h;
}

const heights = new Float32Array(ROW * ROW);
for (let j = 0; j <= CELLS; j++) {
  for (let i = 0; i <= CELLS; i++) heights[j * ROW + i] = sampleHeight(i * TERRAIN_STEP - TERRAIN_EXTENT, j * TERRAIN_STEP - TERRAIN_EXTENT);
}

export function heightAt(x, z) {
  const gx = clamp((x + TERRAIN_EXTENT) / TERRAIN_STEP, 0, CELLS - 1e-9);
  const gz = clamp((z + TERRAIN_EXTENT) / TERRAIN_STEP, 0, CELLS - 1e-9);
  const i = Math.floor(gx), j = Math.floor(gz), u = gx - i, v = gz - j, n = j * ROW + i;
  const a = heights[n], b = heights[n + 1], c = heights[n + ROW], d = heights[n + ROW + 1];
  return u + v <= 1 ? a + (b - a) * u + (c - a) * v : d + (c - d) * (1 - u) + (b - d) * (1 - v);
}

export function normalAt(x, z) {
  const gx = clamp((x + TERRAIN_EXTENT) / TERRAIN_STEP, 0, CELLS - 1e-9);
  const gz = clamp((z + TERRAIN_EXTENT) / TERRAIN_STEP, 0, CELLS - 1e-9);
  const i = Math.floor(gx), j = Math.floor(gz), n = j * ROW + i;
  const a = heights[n], b = heights[n + 1], c = heights[n + ROW], d = heights[n + ROW + 1];
  const first = gx - i + gz - j <= 1;
  const sx = (first ? b - a : d - c) / TERRAIN_STEP, sz = (first ? c - a : d - b) / TERRAIN_STEP;
  const inv = 1 / Math.hypot(sx, 1, sz);
  return { x: -sx * inv, y: inv, z: -sz * inv };
}

export function isLand(x, z, margin = 0) {
  return Math.hypot(x, z) <= coastRadius(Math.atan2(z, x)) - Math.max(0, margin);
}

export function biomeAt(x, z) {
  if (!isLand(x, z)) return 'ocean';
  const h = heightAt(x, z);
  if (h < 2.5) return 'beach';
  if (Math.max(Math.abs(x), Math.abs(z)) <= 48) return 'compound';
  if (z < -57 && h > 14) return 'snow';
  if (x > 55 && z > -55) return 'desert';
  if (x < -53) return 'forest';
  return 'meadow';
}

function mixHex(a, b, t) {
  const r = Math.round(mix(a >> 16 & 255, b >> 16 & 255, t));
  const g = Math.round(mix(a >> 8 & 255, b >> 8 & 255, t));
  const bl = Math.round(mix(a & 255, b & 255, t));
  return r << 16 | g << 8 | bl;
}

export function biomeColor(x, z) {
  const h = heightAt(x, z);
  if (!isLand(x, z)) return h > -2 ? 0x46b5ae : 0x207d91;
  let color = 0x7caa65;
  color = mixHex(color, 0x3f795a, smooth(-48, -80, x));
  const sand = smooth(49, 74, x) * smooth(-62, -35, z);
  color = mixHex(color, 0xc99561, sand);
  if (z < -48) {
    color = mixHex(color, 0x76898b, smooth(10, 17, h));
    color = mixHex(color, 0xe1eddf, smooth(17, 23, h));
  }
  const compound = 1 - smooth(45, 55, Math.max(Math.abs(x), Math.abs(z)));
  color = mixHex(color, 0xa99f80, compound);
  color = mixHex(0xe3cfa2, color, smooth(1.5, 4.0, h));
  const grain = Math.sin(x * 0.22 + z * 0.12) * Math.cos(z * 0.18 - x * 0.08) * 0.045;
  return mixHex(color, grain > 0 ? 0xffffff : 0x1f3b35, Math.abs(grain));
}

// Peso de cada textura de suelo en un punto: [hierba, bosque, arena] y
// [nieve, roca, tierra]. Sigue las mismas transiciones que `biomeColor`.
const SPLAT = ['grass', 'forest_floor', 'sand', 'snow', 'rock', 'dirt'];
export function splatWeights(x, z) {
  const w = [1, 0, 0, 0, 0, 0], h = heightAt(x, z);
  const blend = (layer, t) => {
    if (t <= 0) return;
    for (let i = 0; i < 6; i++) w[i] *= 1 - t;
    w[layer] += t;
  };
  blend(1, smooth(-48, -80, x));
  blend(2, smooth(49, 74, x) * smooth(-62, -35, z));
  if (z < -48) { blend(4, smooth(10, 17, h)); blend(3, smooth(17, 23, h)); }
  blend(5, 1 - smooth(45, 55, Math.max(Math.abs(x), Math.abs(z))));
  blend(2, 1 - smooth(1.5, 4.0, h));
  blend(4, 1 - smooth(0.72, 0.9, normalAt(x, z).y)); // las laderas empinadas muestran roca
  return w;
}

// DDA sobre la rejilla. Cada celda prueba sus dos planos y valida el triángulo.
// Evita un Raycaster sobre 56 448 caras para cada disparo y cada bot.
export function terrainRaycast(ox, oy, oz, dx, dy, dz, maxT) {
  if (!(maxT > 0)) return null;
  let enter = 0, exit = maxT;
  for (let axis = 0; axis < 2; axis++) {
    const o = axis ? oz : ox, d = axis ? dz : dx;
    if (Math.abs(d) < 1e-12) { if (o < -TERRAIN_EXTENT || o > TERRAIN_EXTENT) return null; }
    else {
      let lo = (-TERRAIN_EXTENT - o) / d, hi = (TERRAIN_EXTENT - o) / d;
      if (lo > hi) { const t = lo; lo = hi; hi = t; }
      enter = Math.max(enter, lo); exit = Math.min(exit, hi);
    }
  }
  if (enter > exit) return null;
  const x = ox + dx * (enter + 1e-8), z = oz + dz * (enter + 1e-8);
  let i = clamp(Math.floor((x + TERRAIN_EXTENT) / TERRAIN_STEP), 0, CELLS - 1);
  let j = clamp(Math.floor((z + TERRAIN_EXTENT) / TERRAIN_STEP), 0, CELLS - 1);
  const stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0, stepZ = dz > 0 ? 1 : dz < 0 ? -1 : 0;
  const deltaX = stepX ? TERRAIN_STEP / Math.abs(dx) : Infinity;
  const deltaZ = stepZ ? TERRAIN_STEP / Math.abs(dz) : Infinity;
  let nextX = stepX ? ((i + (stepX > 0 ? 1 : 0)) * TERRAIN_STEP - TERRAIN_EXTENT - ox) / dx : Infinity;
  let nextZ = stepZ ? ((j + (stepZ > 0 ? 1 : 0)) * TERRAIN_STEP - TERRAIN_EXTENT - oz) / dz : Infinity;
  for (let visits = 0; visits <= CELLS * 2 + 2 && i >= 0 && i < CELLS && j >= 0 && j < CELLS; visits++) {
    const end = Math.min(nextX, nextZ, exit), n = j * ROW + i;
    const a = heights[n], b = heights[n + 1], c = heights[n + ROW], d = heights[n + ROW + 1];
    const x0 = i * TERRAIN_STEP - TERRAIN_EXTENT, z0 = j * TERRAIN_STEP - TERRAIN_EXTENT;
    let hit = Infinity, hitX = 0, hitZ = 0;
    for (let tri = 0; tri < 2; tri++) {
      const sx = (tri ? d - c : b - a) / TERRAIN_STEP;
      const sz = (tri ? d - b : c - a) / TERRAIN_STEP;
      const base = tri ? b + c - d : a;
      const denom = dy - sx * dx - sz * dz;
      if (Math.abs(denom) < 1e-10) continue;
      const t = (base + sx * (ox - x0) + sz * (oz - z0) - oy) / denom;
      if (t <= 1e-6 || t < enter - 1e-6 || t > end + 1e-6 || t >= hit) continue;
      const u = (ox + dx * t - x0) / TERRAIN_STEP, v = (oz + dz * t - z0) / TERRAIN_STEP;
      if (u < -1e-6 || u > 1 + 1e-6 || v < -1e-6 || v > 1 + 1e-6) continue;
      if (tri ? u + v < 1 - 1e-6 : u + v > 1 + 1e-6) continue;
      hit = t; hitX = sx; hitZ = sz;
    }
    if (hit < Infinity) {
      const inv = 1 / Math.hypot(hitX, 1, hitZ);
      return { t: hit, kind: 'ground', collider: null, nx: -hitX * inv, ny: inv, nz: -hitZ * inv };
    }
    if (end >= exit) break;
    enter = end;
    if (nextX <= nextZ) { i += stepX; nextX += deltaX; }
    else { j += stepZ; nextZ += deltaZ; }
  }
  return null;
}

// `textures` (opcional): mapas de suelo por bioma; sin ellos queda el color por vértice.
export function createTerrain(scene, textures = null) {
  const textured = !!textures && SPLAT.every((name) => textures[name]);
  const positions = new Float32Array(ROW * ROW * 3), colors = new Float32Array(positions.length);
  const splatA = textured ? new Float32Array(positions.length) : null;
  const splatB = textured ? new Float32Array(positions.length) : null;
  const indices = new Uint32Array(CELLS * CELLS * 6), color = new THREE.Color();
  for (let j = 0; j <= CELLS; j++) {
    for (let i = 0; i <= CELLS; i++) {
      const n = j * ROW + i, x = i * TERRAIN_STEP - TERRAIN_EXTENT, z = j * TERRAIN_STEP - TERRAIN_EXTENT;
      positions[n * 3] = x; positions[n * 3 + 1] = heights[n]; positions[n * 3 + 2] = z;
      color.setHex(biomeColor(x, z)); color.toArray(colors, n * 3);
      if (textured) {
        const w = splatWeights(x, z);
        splatA.set([w[0], w[1], w[2]], n * 3);
        splatB.set([w[3], w[4], w[5]], n * 3);
      }
    }
  }
  let k = 0;
  for (let j = 0; j < CELLS; j++) for (let i = 0; i < CELLS; i++) {
    const n = j * ROW + i;
    indices[k++] = n; indices[k++] = n + ROW; indices[k++] = n + 1;
    indices[k++] = n + 1; indices[k++] = n + ROW; indices[k++] = n + ROW + 1;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  if (textured) {
    geometry.setAttribute('splatA', new THREE.BufferAttribute(splatA, 3));
    geometry.setAttribute('splatB', new THREE.BufferAttribute(splatB, 3));
  }
  geometry.setIndex(new THREE.BufferAttribute(indices, 1));
  geometry.computeVertexNormals();
  const groundMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, flatShading: true });
  // Polvo, motas de grava y manchas suaves dan escala al suelo a la altura
  // del jugador. Se atenúan a distancia para evitar parpadeos en el horizonte.
  groundMaterial.onBeforeCompile = (shader) => {
    shader.vertexShader = 'varying vec2 vSoilXZ;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vSoilXZ = position.xz;');
    if (textured) {
      SPLAT.forEach((name, i) => { shader.uniforms[`soil${i}`] = { value: textures[name] }; });
      shader.vertexShader = 'attribute vec3 splatA;\nattribute vec3 splatB;\nvarying vec3 vSplatA;\nvarying vec3 vSplatB;\n' +
        shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n vSplatA = splatA; vSplatB = splatB;');
    }
    shader.fragmentShader = `varying vec2 vSoilXZ;
      float soilHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float soilNoise(vec2 p) {
        vec2 cell = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(soilHash(cell), soilHash(cell + vec2(1.0, 0.0)), f.x),
          mix(soilHash(cell + vec2(0.0, 1.0)), soilHash(cell + vec2(1.0)), f.x), f.y);
      }\n` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
      float dust = soilNoise(vSoilXZ * 0.28);
      float fine = soilHash(floor(vSoilXZ * 15.0));
      float detail = 1.0 - smoothstep(0.045, 0.22, length(fwidth(vSoilXZ)));
      float compound = 1.0 - smoothstep(46.0, 55.0, max(abs(vSoilXZ.x), abs(vSoilXZ.y)));
      diffuseColor.rgb *= 0.88 + dust * 0.17 + (fine - 0.5) * detail * 0.16;
      diffuseColor.rgb *= mix(vec3(1.0), vec3(0.79, 0.87, 0.68), smoothstep(0.55, 0.85, dust) * compound * 0.5);` +
      (textured ? `
      // Cada capa se muestrea a dos escalas para que la repetición no se note de lejos.
      vec2 soilNear = vSoilXZ * 0.19, soilFar = vSoilXZ * 0.043 + 7.3;
      vec3 soil = vec3(0.0);
      soil += (texture2D(soil0, soilNear).rgb * 0.6 + texture2D(soil0, soilFar).rgb * 0.4) * vSplatA.x;
      soil += (texture2D(soil1, soilNear).rgb * 0.6 + texture2D(soil1, soilFar).rgb * 0.4) * vSplatA.y;
      soil += (texture2D(soil2, soilNear).rgb * 0.6 + texture2D(soil2, soilFar).rgb * 0.4) * vSplatA.z;
      soil += (texture2D(soil3, soilNear).rgb * 0.6 + texture2D(soil3, soilFar).rgb * 0.4) * vSplatB.x;
      soil += (texture2D(soil4, soilNear).rgb * 0.6 + texture2D(soil4, soilFar).rgb * 0.4) * vSplatB.y;
      soil += (texture2D(soil5, soilNear).rgb * 0.6 + texture2D(soil5, soilFar).rgb * 0.4) * vSplatB.z;
      diffuseColor.rgb = mix(diffuseColor.rgb, soil * (0.9 + dust * 0.2), 0.72);` : ''));
    if (textured) {
      shader.fragmentShader = 'varying vec3 vSplatA;\nvarying vec3 vSplatB;\n' +
        SPLAT.map((_, i) => `uniform sampler2D soil${i};\n`).join('') + shader.fragmentShader;
    }
  };
  const ground = new THREE.Mesh(geometry, groundMaterial);
  ground.name = 'Isla · terreno transitable'; ground.receiveShadow = true;
  scene.add(ground);

  const seaGeometry = new THREE.PlaneGeometry(1400, 1400, 100, 100);
  seaGeometry.rotateX(-Math.PI / 2);
  const seaColors = new Float32Array(seaGeometry.attributes.position.count * 3);
  for (let n = 0; n < seaGeometry.attributes.position.count; n++) {
    const x = seaGeometry.attributes.position.getX(n), z = seaGeometry.attributes.position.getZ(n);
    const shoreDistance = Math.hypot(x, z) - coastRadius(Math.atan2(z, x));
    color.setHex(mixHex(0x46b7b4, 0x185471, smooth(0, 120, shoreDistance))).toArray(seaColors, n * 3);
  }
  seaGeometry.setAttribute('color', new THREE.BufferAttribute(seaColors, 3));
  const seaMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.27, metalness: 0.32 });
  const waveTime = { value: 0 };
  seaMaterial.onBeforeCompile = (shader) => {
    shader.uniforms.islandTime = waveTime;
    shader.vertexShader = 'uniform float islandTime;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      transformed.y += sin(position.x * 0.12 + islandTime * 0.6) * 0.065 + cos(position.z * 0.16 - islandTime * 0.45) * 0.045;`);
  };
  const sea = new THREE.Mesh(seaGeometry, seaMaterial);
  sea.name = 'Océano'; sea.position.y = WATER_LEVEL;
  sea.onBeforeRender = () => { waveTime.value = performance.now() * 0.001; };
  scene.add(sea);

  // Dos líneas discontinuas de espuma ayudan a leer el litoral desde tierra y desde arriba.
  const foamPositions = [], foamIndices = [];
  for (let band = 0; band < 2; band++) for (let n = 0; n < 240; n++) {
    if ((n + band * 4) % 13 > 8) continue;
    const a = n / 240 * Math.PI * 2, b = (n + 1) / 240 * Math.PI * 2;
    const ra = coastRadius(a) + 2.5 + band * 3.5, rb = coastRadius(b) + 2.5 + band * 3.5;
    const base = foamPositions.length / 3, width = band ? 0.24 : 0.45;
    foamPositions.push(Math.cos(a) * ra, WATER_LEVEL + 0.13, Math.sin(a) * ra,
      Math.cos(a) * (ra + width), WATER_LEVEL + 0.13, Math.sin(a) * (ra + width),
      Math.cos(b) * rb, WATER_LEVEL + 0.13, Math.sin(b) * rb,
      Math.cos(b) * (rb + width), WATER_LEVEL + 0.13, Math.sin(b) * (rb + width));
    foamIndices.push(base, base + 2, base + 1, base + 1, base + 2, base + 3);
  }
  const foamGeo = new THREE.BufferGeometry();
  foamGeo.setAttribute('position', new THREE.Float32BufferAttribute(foamPositions, 3));
  foamGeo.setIndex(foamIndices);
  const foam = new THREE.Mesh(foamGeo, new THREE.MeshBasicMaterial({ color: 0xc8eee0, transparent: true, opacity: 0.5, depthWrite: false, side: THREE.DoubleSide }));
  foam.name = 'Espuma costera'; scene.add(foam);
  return { ground, sea, foam };
}

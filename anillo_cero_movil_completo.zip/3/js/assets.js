// Recursos generados con Higgsfield: modelos GLB, texturas de superficie y sonidos.
// El juego sigue funcionando con primitivas si alguno no llega a cargarse.
import * as THREE from 'three';
import { nearFade } from './materials.js';

// `yaw` alinea cada modelo con el eje que espera el juego (el eje largo en X,
// o el cañón de un arma hacia -Z). `shadow: false` evita sombras de detalle.
// `foliage` hace que se desvanezca junto a la cámara.
export const MODELS = {
  crate: {},
  stone_block: {},
  pod: { yaw: Math.PI / 2 },
  rock_grey: {},
  rock_sand: {},
  rock_snow: {},
  tree_oak: { foliage: true },
  tree_pine: { foliage: true },
  tree_pine_snow: { foliage: true },
  palm: { foliage: true },
  cactus: { foliage: true },
  bush: { shadow: false, foliage: true },
  flowers: { shadow: false },
  barrier: {},
  container: {},
  solar_panel: {},
  pickup_ammo: {},
  pickup_shield: {},
  pickup_med: {},
  pickup_mats: {},
  gun_rifle: { yaw: Math.PI },
  gun_shotgun: { yaw: Math.PI },
  gun_smg: { yaw: Math.PI },
  build_tool: { yaw: Math.PI },
};

export const TEXTURES = [
  'grass', 'forest_floor', 'sand', 'snow', 'rock', 'dirt',
  'wall_ivory', 'metal_dark', 'metal_painted', 'sandstone', 'stone_ruin', 'wood_planks', 'asphalt', 'concrete_dark',
];

export const SOUNDS = [
  'step_grass', 'step_sand', 'step_snow', 'step_concrete', 'step_wood', 'step_metal',
  'jump', 'land', 'slide', 'reload_out', 'reload_in', 'shell_insert', 'dry_fire', 'weapon_switch',
  'hit_body', 'hit_head', 'kill', 'hurt_1', 'hurt_2', 'shield_break', 'low_health',
  'impact_dirt', 'impact_metal', 'impact_energy', 'whiz', 'build_place', 'build_break',
  'pickup_ammo', 'pickup_shield', 'pickup_heal', 'pickup_mats', 'pod_open',
  'zone_alarm', 'zone_burn', 'win', 'lose', 'ui_click', 'match_start',
  'amb_ocean', 'amb_forest', 'amb_meadow', 'amb_snow', 'amb_desert', 'amb_compound',
];

// Deja la malla en una caja unidad con la base en y = 0 y centrada en XZ.
// Así `escala = tamaño final en metros`, igual que los bloques del mapa;
// `size` conserva las proporciones originales para no deformar al colocar.
export function prepareModel(root, { yaw = 0, shadow = true, foliage = false } = {}) {
  root.updateMatrixWorld(true);
  const parts = [], box = new THREE.Box3(), turn = new THREE.Matrix4().makeRotationY(yaw);
  root.traverse((o) => {
    if (!o.isMesh) return;
    const geometry = o.geometry.clone().applyMatrix4(o.matrixWorld).applyMatrix4(turn);
    geometry.computeBoundingBox();
    box.union(geometry.boundingBox);
    const src = Array.isArray(o.material) ? o.material[0] : o.material;
    const material = new THREE.MeshStandardMaterial({ map: src.map || null, color: src.map ? 0xffffff : src.color, roughness: 0.88, metalness: 0 });
    if (material.map) material.map.anisotropy = 4;
    if (foliage) nearFade(material);
    parts.push({ geometry, material });
  });
  const size = box.getSize(new THREE.Vector3()), center = box.getCenter(new THREE.Vector3());
  const fit = new THREE.Matrix4().makeScale(1 / size.x, 1 / size.y, 1 / size.z)
    .multiply(new THREE.Matrix4().makeTranslation(-center.x, -box.min.y, -center.z));
  for (const p of parts) {
    p.geometry.applyMatrix4(fit);
    p.geometry.computeBoundingBox();
    p.geometry.computeBoundingSphere();
    p.geometry.userData.noShadow = !shadow;
  }
  return { parts, size };
}

export class Assets {
  constructor(base = 'assets/') {
    this.base = base;
    this.models = {};
    this.textures = {};
    this.audio = {};
    this.failed = [];
    this.tints = new Map();
  }

  model(name) { return this.models[name] || null; }

  // Tamaño final que conserva las proporciones del modelo para una altura dada.
  natural(name, height) {
    const s = this.models[name].size;
    return [s.x / s.y * height, height, s.z / s.y * height];
  }

  // Las mismas piezas con el material teñido; un material por color.
  tinted(name, hex) {
    const key = `${name}:${hex}`;
    if (!this.tints.has(key)) {
      this.tints.set(key, this.models[name].parts.map((p) => {
        const material = p.material.clone();
        material.color.setHex(hex);
        return { geometry: p.geometry, material };
      }));
    }
    return this.tints.get(key);
  }

  async load(onProgress = () => {}) {
    const { GLTFLoader } = await import('../vendor/addons/loaders/GLTFLoader.js');
    const gltf = new GLTFLoader(), textures = new THREE.TextureLoader();
    const total = Object.keys(MODELS).length + TEXTURES.length + SOUNDS.length;
    let done = 0;
    const track = (label, promise) => promise
      .catch((error) => { this.failed.push(label); console.warn(`No se pudo cargar ${label}:`, error); })
      .finally(() => onProgress(++done / total));

    const jobs = [];
    for (const [name, options] of Object.entries(MODELS)) {
      jobs.push(track(`modelo ${name}`, gltf.loadAsync(`${this.base}models/${name}.glb`).then((file) => {
        this.models[name] = prepareModel(file.scene, options);
      })));
    }
    for (const name of TEXTURES) {
      jobs.push(track(`textura ${name}`, textures.loadAsync(`${this.base}textures/${name}.jpg`).then((texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        // El reflejo en cada repetición oculta las juntas de una textura que no sea perfectamente continua.
        texture.wrapS = texture.wrapT = THREE.MirroredRepeatWrapping;
        texture.anisotropy = 8;
        this.textures[name] = texture;
      })));
    }
    for (const name of SOUNDS) {
      jobs.push(track(`sonido ${name}`, fetch(`${this.base}audio/${name}.mp3`).then((response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.arrayBuffer();
      }).then((data) => { this.audio[name] = data; })));
    }
    await Promise.all(jobs);
    return this;
  }
}

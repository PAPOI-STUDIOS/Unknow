// Teclado y ratón. `pressed` / `mousePressed` solo duran un fotograma.
const GAME_KEYS = new Set([
  'KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'ShiftLeft', 'KeyC', 'ControlLeft', 'KeyR', 'KeyE',
  'KeyQ', 'KeyF', 'KeyZ', 'Digit1', 'Digit2', 'Digit3', 'Tab',
]);

// La entrada sin aceleración evita los saltos que puede producir el cursor
// del sistema al recentrarse. Algunos navegadores solo admiten captura normal.
export async function requestGamePointerLock(target) {
  try {
    await target.requestPointerLock({ unadjustedMovement: true });
  } catch (error) {
    if (error.name !== 'NotSupportedError') throw error;
    await target.requestPointerLock();
  }
}

export class Input {
  constructor() {
    this.keys = new Set();
    this.pressed = new Set();
    this.mouse = [false, false, false];
    this.mousePressed = [false, false, false];
    this.dx = 0;
    this.dy = 0;
    this.wheel = 0;
    this.enabled = false; // solo durante la partida
    this.locked = false;  // puntero capturado
    this.freeLook = false; // modo de pruebas sin captura de puntero
    this.skipMotion = false;
    this.screenPosition = null;

    addEventListener('keydown', (e) => {
      if (!this.enabled) return;
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      this.pressed.add(e.code);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('mousedown', (e) => {
      if (!this.enabled || !(this.locked || this.freeLook) || e.button > 2) return;
      this.mouse[e.button] = true;
      this.mousePressed[e.button] = true;
    });
    addEventListener('mouseup', (e) => {
      if (e.button <= 2) this.mouse[e.button] = false;
    });
    addEventListener('mousemove', (e) => {
      if (!this.enabled || !(this.locked || this.freeLook)) return;
      const dx = e.movementX, dy = e.movementY;
      if (!Number.isFinite(dx) || !Number.isFinite(dy)) return;

      // Bajo Pointer Lock las coordenadas de pantalla deben ser constantes.
      // Un cambio absoluto es una transición/recentrado, no movimiento relativo
      // del jugador. No limitar los deltas válidos: también se permiten giros rápidos.
      let repositioned = false;
      if (this.locked && Number.isFinite(e.screenX) && Number.isFinite(e.screenY)) {
        const previous = this.screenPosition;
        repositioned = previous !== null && (previous.x !== e.screenX || previous.y !== e.screenY);
        this.screenPosition = { x: e.screenX, y: e.screenY };
      }
      if (this.skipMotion || repositioned) {
        this.skipMotion = false;
        return;
      }
      this.dx += dx;
      this.dy += dy;
    });
    addEventListener('wheel', (e) => {
      if (this.enabled) this.wheel += Math.sign(e.deltaY);
    }, { passive: true });
    addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('blur', () => this.clear());

    // Entrada táctil: joystick izquierdo y cámara por arrastre a la derecha.
    this.touchPointers = new Map();
    const touchMode = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
    const controls = document.getElementById('touch-controls');
    if (controls && touchMode) {
      const setKey = (k, on, edge=false) => { if (on) { this.keys.add(k); if(edge) this.pressed.add(k); } else this.keys.delete(k); };
      const actions = {jump:['Space'],sprint:['ShiftLeft'],crouch:['KeyC'],reload:['KeyR',true],interact:['KeyE',true],weapon1:['Digit1',true],weapon2:['Digit2',true],weapon3:['Digit3',true],fire:['M0'],aim:['M2']};
      controls.querySelectorAll('[data-touch]').forEach(btn => {
        const name=btn.dataset.touch, a=actions[name]; if(!a)return;
        const end=()=>{if(a[0]==='M0')this.mouse[0]=false;else if(a[0]==='M2')this.mouse[2]=false;else setKey(a[0],false);btn.classList.remove('active');};
        btn.addEventListener('pointerdown',e=>{if(!this.enabled)return;e.preventDefault();e.stopPropagation();btn.setPointerCapture(e.pointerId);if(a[0]==='M0')this.mouse[0]=true;else if(a[0]==='M2')this.mouse[2]=true;else setKey(a[0],true,!!a[1]);btn.classList.add('active');});
        btn.addEventListener('pointerup',end);btn.addEventListener('pointercancel',end);btn.addEventListener('lostpointercapture',end);
      });
      const stick=document.getElementById('touch-stick');
      if(stick){
        const move=e=>{const r=stick.getBoundingClientRect(),mx=r.left+r.width/2,my=r.top+r.height/2,lim=r.width*.34,dx=e.clientX-mx,dy=e.clientY-my,k=Math.min(1,lim/Math.max(1,Math.hypot(dx,dy))),x=dx*k/lim,y=dy*k/lim;this.touchVector={x,y};stick.querySelector('i').style.transform=`translate(${x*lim}px,${y*lim}px)`;setKey('KeyA',x<-.22);setKey('KeyD',x>.22);setKey('KeyW',y<-.22);setKey('KeyS',y>.22);};
        stick.addEventListener('pointerdown',e=>{if(!this.enabled)return;e.preventDefault();stick.setPointerCapture(e.pointerId);this.touchPointers.set(e.pointerId,'stick');move(e);});
        stick.addEventListener('pointermove',e=>{if(this.touchPointers.get(e.pointerId)==='stick')move(e);});
        const stop=e=>{if(this.touchPointers.get(e.pointerId)!=='stick')return;this.touchPointers.delete(e.pointerId);['KeyA','KeyD','KeyW','KeyS'].forEach(k=>setKey(k,false));stick.querySelector('i').style.transform='';};
        stick.addEventListener('pointerup',stop);stick.addEventListener('pointercancel',stop);
      }
      const look=document.getElementById('touch-look');
      if(look){
        look.addEventListener('pointerdown',e=>{if(!this.enabled)return;e.preventDefault();look.setPointerCapture(e.pointerId);this.touchPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});});
        look.addEventListener('pointermove',e=>{const p=this.touchPointers.get(e.pointerId);if(!p||p==='stick')return;this.dx+=(e.clientX-p.x)*1.35;this.dy+=(e.clientY-p.y)*1.35;this.touchPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});});
        const stop=e=>this.touchPointers.delete(e.pointerId);look.addEventListener('pointerup',stop);look.addEventListener('pointercancel',stop);
      }
    }

  }

  down(code) { return this.keys.has(code); }
  hit(code) { return this.pressed.has(code); }

  setLocked(locked) {
    if (this.locked === locked) return;
    this.locked = locked;
    this.clear();
  }

  clear() {
    this.keys.clear();
    this.pressed.clear();
    this.mouse.fill(false);
    this.mousePressed.fill(false);
    this.dx = this.dy = this.wheel = 0;
    this.screenPosition = null;
    this.skipMotion = this.locked;
  }

  endFrame() {
    this.pressed.clear();
    this.mousePressed.fill(false);
    this.dx = this.dy = this.wheel = 0;
  }
}

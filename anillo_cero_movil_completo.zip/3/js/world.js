// Mundo: colisionadores, trazado de rayos y generación del mapa.
import * as THREE from 'three';
import { rng32 } from './util.js';
import { rayAABB, hitN, rampHeight } from './physics.js';
import { std, triplanar } from './materials.js';
import { heightAt, normalAt, isLand, biomeAt, coastRadius, terrainRaycast, createTerrain } from './terrain.js';

const unitBox = new THREE.BoxGeometry(1, 1, 1);

export class World {
  constructor(scene) {
    this.scene = scene;
    this.boxes = [];
    this.ramps = [];
    this.pods = [];      // posiciones para cápsulas de suministro
    this.spawns = [];
    this.landmarks = [];
  }

  groundHeight(x, z) { return heightAt(x, z); }
  groundNormal(x, z) { return normalAt(x, z); }
  isLand(x, z, margin = 0) { return isLand(x, z, margin); }

  // Una costa continua sustituye las cuatro paredes invisibles del recinto.
  constrainPosition(b) {
    const angle = Math.atan2(b.z, b.x), d = Math.hypot(b.x, b.z);
    const limit = coastRadius(angle) - (b.r || 0.38) - 2.5;
    if (d > limit) {
      const nx = b.x / d, nz = b.z / d;
      b.x = nx * limit; b.z = nz * limit;
      const outward = b.vx * nx + b.vz * nz;
      if (outward > 0) { b.vx -= outward * nx; b.vz -= outward * nz; }
    }
  }

  // Material bajo los pies, para elegir el sonido de las pisadas.
  surfaceAt(b) {
    const s = b.support;
    if (s) return s.piece ? 'metal' : s.surface || 'concrete';
    const biome = biomeAt(b.x, b.z);
    if (biome === 'beach' || biome === 'desert') return 'sand';
    if (biome === 'snow') return 'snow';
    return biome === 'compound' ? 'concrete' : 'grass';
  }

  addBox(x0, y0, z0, x1, y1, z1, extra) {
    const c = { min: { x: x0, y: y0, z: z0 }, max: { x: x1, y: y1, z: z1 }, piece: null, ...extra };
    this.boxes.push(c);
    return c;
  }

  addRamp(x0, z0, x1, z1, y0, rise, dir, extra) {
    const rp = { x0, z0, x1, z1, y0, rise, dir, solid: false, piece: null, ...extra };
    this.ramps.push(rp);
    return rp;
  }

  remove(c) {
    let i = this.boxes.indexOf(c);
    if (i >= 0) { this.boxes.splice(i, 1); return; }
    i = this.ramps.indexOf(c);
    if (i >= 0) this.ramps.splice(i, 1);
  }

  // Devuelve { t, kind, collider, nx, ny, nz } del impacto más cercano o null.
  raycast(ox, oy, oz, dx, dy, dz, maxT) {
    let best = maxT, res = null;
    for (const c of this.boxes) {
      const t = rayAABB(ox, oy, oz, dx, dy, dz, c.min.x, c.min.y, c.min.z, c.max.x, c.max.y, c.max.z);
      if (t > 0 && t < best) { best = t; res = { t, kind: 'box', collider: c, nx: hitN[0], ny: hitN[1], nz: hitN[2] }; }
    }
    for (const rp of this.ramps) {
      const alongX = rp.dir % 2 === 0;
      const L = alongX ? rp.x1 - rp.x0 : rp.z1 - rp.z0;
      const ux = rp.dir === 0 ? 1 : rp.dir === 2 ? -1 : 0;
      const uz = rp.dir === 1 ? 1 : rp.dir === 3 ? -1 : 0;
      const px = rp.dir === 2 ? rp.x1 : rp.x0, pz = rp.dir === 3 ? rp.z1 : rp.z0;
      const k = rp.rise / L;
      const f0 = rp.y0 + k * ((ox - px) * ux + (oz - pz) * uz) - oy; // > 0: origen bajo la superficie
      const den = k * (dx * ux + dz * uz) - dy;
      if (Math.abs(den) > 1e-7) {
        const t = -f0 / den;
        if (t > 0 && t < best) {
          const hx = ox + dx * t, hz = oz + dz * t;
          if (hx >= rp.x0 && hx <= rp.x1 && hz >= rp.z0 && hz <= rp.z1) {
            const s = (f0 > 0 ? -1 : 1) / Math.hypot(k, 1);
            best = t;
            res = { t, kind: 'ramp', collider: rp, nx: -k * ux * s, ny: s, nz: -k * uz * s };
          }
        }
      }
      if (rp.solid) {
        const t = rayAABB(ox, oy, oz, dx, dy, dz, rp.x0, rp.y0, rp.z0, rp.x1, rp.y0 + rp.rise, rp.z1);
        if (t > 0 && t < best) {
          const ex = ox + dx * t, ey = oy + dy * t, ez = oz + dz * t;
          if (ey <= rampHeight(rp, ex, ez) + 0.01) {
            best = t;
            res = { t, kind: 'box', collider: rp, nx: hitN[0], ny: hitN[1], nz: hitN[2] };
          }
        }
      }
    }
    const terrain = terrainRaycast(ox, oy, oz, dx, dy, dz, best);
    return terrain || res;
  }

  // ¿Hay sitio libre para un personaje alrededor de (x, z)?
  isFree(x, z, margin = 1) {
    if (!isLand(x, z, margin + 3) || normalAt(x, z).y < 0.78) return false;
    const y = heightAt(x, z);
    for (const c of this.boxes) {
      if (c.max.y <= y + 0.08 || c.min.y >= y + 2.2) continue;
      if (x + margin > c.min.x && x - margin < c.max.x && z + margin > c.min.z && z - margin < c.max.z) return false;
    }
    for (const rp of this.ramps) {
      if (x + margin > rp.x0 && x - margin < rp.x1 && z + margin > rp.z0 && z - margin < rp.z1) return false;
    }
    return true;
  }
}

// ---------------------------------------------------------------------------
// Generación del mapa
// ---------------------------------------------------------------------------

function wedgeGeometry() {
  // Prisma triangular unitario: sube de x=-0.5 (y=0) a x=+0.5 (y=1), z en [-0.5, 0.5].
  const a = [-0.5, 0, -0.5], b = [0.5, 0, -0.5], c = [0.5, 1, -0.5];
  const d = [-0.5, 0, 0.5], e = [0.5, 0, 0.5], f = [0.5, 1, 0.5];
  const tris = [
    a, c, b, d, e, f,       // laterales
    a, d, f, a, f, c,       // pendiente
    b, c, f, b, f, e,       // trasera
    a, b, e, a, e, d,       // base
  ];
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(tris.flat(), 3));
  geo.computeVertexNormals();
  return geo;
}

// `assets` (opcional) aporta modelos GLB y texturas; sin él se dibuja con primitivas.
export function buildArena(world, scene, seed, mode, assets = null) {
  const rng = rng32(seed), dense = mode === 'nobuild';
  // La variación puramente visual usa su propia secuencia: colisiones, suministros
  // y apariciones son idénticos con o sin recursos cargados.
  const vr = rng32(seed ^ 0x5bd1e995);
  const T = assets?.textures || {};
  createTerrain(scene, T);
  // Con textura, el color del material pasa a ser un tinte claro sobre ella.
  const tex = (name, plain, tint, scale, extra) => triplanar(std(T[name] ? tint : plain, extra), T[name], scale);
  const M = {
    ivory: tex('wall_ivory', 0xdce4d7, 0xf4f6ee, 0.3), dark: tex('concrete_dark', 0x647779, 0xcfd9d6, 0.45),
    metal: tex('metal_dark', 0x263d4b, 0xaebccb, 0.5, { metalness: 0.4, roughness: 0.45 }),
    teal: tex('metal_painted', 0x2d9692, 0x35aaa5, 0.4), orange: tex('metal_painted', 0xe88b48, 0xf09a56, 0.4),
    yellow: tex('metal_painted', 0xe1b75d, 0xeec668, 0.4), stone: tex('stone_ruin', 0x9baca3, 0xe6ece6, 0.4),
    sandstone: tex('sandstone', 0xc78d60, 0xf0dccb, 0.3), timber: tex('wood_planks', 0x705445, 0xcdbcab, 0.5),
    trunk: std(0x665345), road: tex('asphalt', 0x667b73, 0xdde6df, 0.25),
    forest: std(0x38876c), pine: std(0x356c6a), snow: std(0xe5eff0), grass: std(0x76a96a),
    glow: std(0x76efd5, { emissive: 0x44cdb9, emissiveIntensity: 1.1 }),
    amber: std(0xffcd7b, { emissive: 0xffa34d, emissiveIntensity: 0.7 }),
    solar: std(0x254f70, { metalness: 0.55, roughness: 0.23 }),
  };
  const wedgeGeo = wedgeGeometry(), rockGeo = new THREE.DodecahedronGeometry(1, 0);
  const coneGeo = new THREE.ConeGeometry(1, 1, 7), trunkGeo = new THREE.CylinderGeometry(0.7, 1, 1, 7);
  const sphereGeo = new THREE.IcosahedronGeometry(1, 0);
  const batches = new Map(), occupied = [];
  const dummy = new THREE.Object3D();
  // Los modelos se agrupan además por sector de 56 m: cada lote tiene su propia
  // esfera envolvente y la cámara descarta los bosques que quedan fuera de vista.
  const inst = (geo, material, x, y, z, sx, sy, sz, rx = 0, ry = 0, rz = 0, chunked = false) => {
    const chunk = chunked ? `${Math.floor((x + 168) / 56)},${Math.floor((z + 168) / 56)}` : '';
    const key = `${geo.uuid}:${material.uuid}:${chunk}`;
    if (!batches.has(key)) batches.set(key, { geo, material, transforms: [] });
    batches.get(key).transforms.push([x, y, z, sx, sy, sz, rx, ry, rz]);
  };
  const mark = (x0, z0, x1, z1) => occupied.push({ x0, z0, x1, z1 });
  const clear = (x, z, r = 2) => !occupied.some(o => x + r > o.x0 && x - r < o.x1 && z + r > o.z0 && z - r < o.z1);
  const block = (x0, y0, z0, x1, y1, z1, material, collide = true) => {
    inst(unitBox, material, (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, x1 - x0, y1 - y0, z1 - z0);
    if (collide) world.addBox(x0, y0, z0, x1, y1, z1, material === M.timber ? { surface: 'wood' } : undefined);
  };
  const wedge = (x0, z0, x1, z1, y, rise, dir, material = M.dark) => {
    const along = dir % 2 === 0 ? x1 - x0 : z1 - z0, across = dir % 2 === 0 ? z1 - z0 : x1 - x0;
    inst(wedgeGeo, material, (x0 + x1) / 2, y, (z0 + z1) / 2, along, rise, across, 0, [0, -Math.PI / 2, Math.PI, Math.PI / 2][dir]);
    world.addRamp(x0, z0, x1, z1, y, rise, dir, { solid: true, surface: material === M.timber ? 'wood' : undefined });
  };
  const pod = (x, z, y = heightAt(x, z)) => { world.pods.push({ x, y, z }); mark(x - 1.2, z - 1.2, x + 1.2, z + 1.2); };
  const landmark = (name, x, z, color) => world.landmarks.push({ name, x, z, color });
  // --- Modelos 3D, con las primitivas de siempre como alternativa ---
  const has = (name) => !!assets?.model?.(name);
  const prop = (name, x, y, z, w, h, d, ry = 0, tint) => {
    const parts = tint === undefined ? assets.model(name).parts : assets.tinted(name, tint);
    for (const p of parts) inst(p.geometry, p.material, x, y, z, w, h, d, 0, ry, 0, true);
  };
  const tintOf = (material, amount) => new THREE.Color(0xffffff).lerp(material.color, amount).getHex();
  const quarter = () => Math.floor(vr() * 4) * Math.PI / 2;
  // Barrera de hormigón: tramos de unos 2 m para no deformar el modelo.
  const barrier = (x0, y0, z0, x1, y1, z1) => {
    const alongX = x1 - x0 >= z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    const length = alongX ? x1 - x0 : z1 - z0, half = 0.42;
    if (alongX) { z0 = cz - half; z1 = cz + half; } else { x0 = cx - half; x1 = cx + half; }
    if (!has('barrier')) { block(x0, y0, z0, x1, y1, z1, M.dark); return; }
    world.addBox(x0, y0, z0, x1, y1, z1);
    const n = Math.max(1, Math.round(length / 2)), step = length / n;
    for (let k = 0; k < n; k++) {
      const off = -length / 2 + step * (k + 0.5);
      prop('barrier', alongX ? cx + off : cx, y0, alongX ? cz : cz + off, step, y1 - y0, half * 2 + 0.16, alongX ? 0 : Math.PI / 2);
    }
  };
  const crate = (x, y, z, color = M.orange, size = 1.3) => {
    const name = color === M.stone ? 'stone_block' : 'crate';
    if (has(name)) {
      world.addBox(x - size / 2, y, z - size / 2, x + size / 2, y + size, z + size / 2);
      prop(name, x, y, z, size, size, size, quarter(), name === 'crate' ? tintOf(color, 0.4) : undefined);
      return;
    }
    block(x - size / 2, y, z - size / 2, x + size / 2, y + size, z + size / 2, color);
    block(x - size / 2 - 0.015, y + 0.2, z - size / 2 - 0.015, x + size / 2 + 0.015, y + 0.28, z + size / 2 + 0.015, M.metal, false);
    block(x - size / 2 - 0.015, y + size - 0.28, z - size / 2 - 0.015, x + size / 2 + 0.015, y + size - 0.2, z + size / 2 + 0.015, M.metal, false);
  };

  // El antiguo recinto de 192 m ahora ocupa 96 m: se conserva su relé y sus
  // cuatro puestos, pero las rutas salen hacia la isla, sin muros perimetrales.
  landmark('RELÉ CERO', 0, 0, '#eacb8e');
  const y = 4;
  block(-48, y + 0.012, -3.2, 48, y + 0.035, 3.2, M.road, false);
  block(-3.2, y + 0.014, -48, 3.2, y + 0.037, 48, M.road, false);
  for (let s = -44; s < 48; s += 8) {
    if (Math.abs(s) < 12) continue;
    block(s, y + 0.04, -0.08, s + 3.2, y + 0.055, 0.08, M.yellow, false);
    block(-0.08, y + 0.04, s, 0.08, y + 0.055, s + 3.2, M.yellow, false);
  }
  block(-7, y, -7, 7, y + 3, 7, M.ivory);
  wedge(7, -2, 12, 2, y, 3, 2);
  wedge(-12, -2, -7, 2, y, 3, 0);
  wedge(-2, 7, 2, 12, y, 3, 3);
  for (const sx of [-1, 1]) {
    const x0 = sx < 0 ? -7 : 3;
    block(x0, y + 3, -7, x0 + 4, y + 4, -6.6, M.dark);
    block(x0, y + 3, 6.6, x0 + 4, y + 4, 7, M.dark);
    block(x0, y + 3.72, -7.02, x0 + 4, y + 3.8, -6.98, M.glow, false);
  }
  block(-0.65, y + 3, -0.65, 0.65, y + 15, 0.65, M.metal);
  block(-2.5, y + 11.5, -0.25, 2.5, y + 11.9, 0.25, M.ivory, false);
  block(-0.4, y + 14.9, -0.4, 0.4, y + 15.6, 0.4, M.amber, false);
  const relayRing = new THREE.Mesh(new THREE.TorusGeometry(2.4, 0.1, 6, 32), M.glow);
  relayRing.position.set(0, y + 10.5, 0); relayRing.rotation.x = Math.PI / 2; scene.add(relayRing);
  mark(-13, -9, 13, 13); pod(4, -3, y + 3);

  const outpost = (cx, cz, color) => {
    const by = heightAt(cx, cz), flip = cz < 0 ? 1 : -1;
    const B = (x0, y0, z0, x1, y1, z1, mat, collide = true) => {
      const za = cz + z0 * flip, zb = cz + z1 * flip;
      block(cx + x0, by + y0, Math.min(za, zb), cx + x1, by + y1, Math.max(za, zb), mat, collide);
    };
    B(-7, 0, -5.5, 7, 3.8, -5, M.ivory);
    B(-7, 0, -5, -6.5, 3.8, 4, M.ivory);
    B(6.5, 0, -5, 7, 3.8, 1, M.ivory);
    B(-7.3, 3.8, -5.8, 0, 4.15, 1, color);
    B(-0.4, 0, 0.2, 0, 3.8, 0.7, M.metal);
    B(-6.8, 2.4, -4.98, 6.8, 2.55, -4.95, color, false);
    B(-7.05, 0.8, 3.8, -6.45, 2.2, 4.3, color);
    const ba = cz + 3.5 * flip, bb = cz + 4.1 * flip;
    barrier(cx + 2.4, by, Math.min(ba, bb), cx + 6, by + 1.1, Math.max(ba, bb));
    B(-7.1, 3.5, -5.6, -0.2, 3.65, -5.3, M.glow, false);
    crate(cx - 4.7, by, cz - 3 * flip, color);
    const za = cz - 4.7 * flip, zb = cz - 0.7 * flip;
    wedge(cx, Math.min(za, zb), cx + 6, Math.max(za, zb), by, 4.15, 2, M.dark);
    mark(cx - 8, cz - 7, cx + 8, cz + 6);
    pod(cx - 4, cz + 1.8 * flip, by);
  };
  outpost(-28, -27, M.teal); outpost(28, -27, M.orange);
  outpost(-28, 27, M.yellow); outpost(28, 27, M.teal);

  // Mesetas pequeñas con rampas: cobertura vertical del mapa original.
  for (const sx of [-1, 1]) {
    const cx = sx * 34;
    block(cx - 6, y, -5, cx + 6, y + 3, 5, M.sandstone);
    block(cx - 5, y + 3, -4, cx, y + 5.5, 1, M.stone);
    wedge(cx - 2, 5, cx + 2, 10, y, 3, 3, M.dark);
    wedge(cx, -4, cx + 5, 0, y + 3, 2.5, 2, M.stone);
    mark(cx - 7, -6, cx + 7, 11); pod(cx + 3.2, 2, y + 3);
  }

  // Depósitos de carga junto a la pista, con nervaduras y puertas.
  for (const [cx, cz, color] of [[-17, 16, M.teal], [17, -17, M.orange], [17, 16, M.yellow], [-17, -17, M.teal]]) {
    if (has('container')) {
      world.addBox(cx - 1.5, y, cz - 3.5, cx + 1.5, y + 2.7, cz + 3.5);
      prop('container', cx, y, cz, 7, 2.7, 3, Math.PI / 2, tintOf(color, 0.8));
    } else {
      block(cx - 1.5, y, cz - 3.5, cx + 1.5, y + 2.7, cz + 3.5, color);
      for (let rz = -3; rz <= 3; rz += 0.7) {
        block(cx - 1.54, y + 0.15, cz + rz, cx - 1.5, y + 2.55, cz + rz + 0.1, M.ivory, false);
        block(cx + 1.5, y + 0.15, cz + rz, cx + 1.54, y + 2.55, cz + rz + 0.1, M.ivory, false);
      }
      block(cx - 1.35, y + 0.1, cz + 3.5, cx + 1.35, y + 2.6, cz + 3.55, M.metal, false);
    }
    mark(cx - 2, cz - 4, cx + 2, cz + 4);
  }

  // BOSQUE: arcos de un observatorio antiguo invadido por vegetación.
  const forestX = -82, forestZ = -32, fy = heightAt(forestX, forestZ);
  landmark('RUINAS VERDES', forestX, forestZ, '#69bea0');
  mark(forestX - 14, forestZ - 14, forestX + 14, forestZ + 14);
  for (const x of [-8, 0, 8]) {
    for (const z of [-6, 6]) {
      const h = x === 8 && z === 6 ? 2.2 : 5;
      block(forestX + x - 0.7, fy - 0.4, forestZ + z - 0.7, forestX + x + 0.7, fy + h, forestZ + z + 0.7, M.stone);
      block(forestX + x - 1, fy + h - 0.25, forestZ + z - 1, forestX + x + 1, fy + h, forestZ + z + 1, M.ivory);
    }
  }
  block(forestX - 8.8, fy + 4.7, forestZ - 6.8, forestX + 8.8, fy + 5.4, forestZ - 5.2, M.ivory);
  block(forestX - 8.8, fy + 4.7, forestZ + 5.2, forestX + 0.8, fy + 5.4, forestZ + 6.8, M.ivory);
  block(forestX - 8.8, fy + 4.7, forestZ - 5.2, forestX - 7.2, fy + 5.4, forestZ + 5.2, M.ivory);
  block(forestX - 2.7, fy, forestZ - 2.7, forestX + 2.7, fy + 0.4, forestZ + 2.7, M.stone);
  const relic = new THREE.Mesh(new THREE.OctahedronGeometry(1.3), M.glow);
  relic.position.set(forestX, fy + 2.4, forestZ); scene.add(relic);
  block(forestX - 0.8, fy + 0.4, forestZ - 0.8, forestX + 0.8, fy + 1.4, forestZ + 0.8, M.metal);
  pod(forestX + 4, forestZ + 2, fy);
  for (let i = 0; i < 7; i++) {
    const x = forestX - 11 + rng() * 22, z = forestZ + 9 + rng() * 2;
    crate(x, fy, z, M.stone, 0.7 + rng() * 0.5);
  }

  // DESIERTO: estación energética y paneles, silueta cálida frente al mar.
  const dx = 86, dz = 26, dy = heightAt(dx, dz);
  landmark('DUNA SOLAR', dx, dz, '#e4b16a');
  mark(dx - 16, dz - 15, dx + 16, dz + 15);
  block(dx - 6, dy - 0.4, dz - 5, dx + 6, dy + 3.8, dz - 4.5, M.sandstone);
  block(dx - 6, dy - 0.4, dz - 4.5, dx - 5.5, dy + 3.8, dz + 4, M.sandstone);
  block(dx + 5.5, dy - 0.4, dz - 4.5, dx + 6, dy + 3.8, dz + 4, M.sandstone);
  block(dx - 6.5, dy + 3.8, dz - 5.5, dx + 6.5, dy + 4.15, dz + 4.5, M.orange);
  block(dx - 2, dy + 0.05, dz - 4.45, dx + 2, dy + 1.8, dz - 3.5, M.metal);
  block(dx - 1.6, dy + 0.9, dz - 3.51, dx + 1.6, dy + 1.5, dz - 3.47, M.glow, false);
  for (const sx of [-1, 1]) {
    for (const zz of [-8, 0, 8]) {
      const x = dx + sx * 11, z = dz + zz;
      if (has('solar_panel')) {
        world.addBox(x - 0.2, dy - 0.3, z - 0.2, x + 0.2, dy + 1.9, z + 0.2);
        const [w, h, d] = assets.natural('solar_panel', 4.2);
        prop('solar_panel', x, dy - 0.05, z, w, h, d, Math.PI); // de cara al centro de la isla
      } else {
        block(x - 0.2, dy - 0.3, z - 0.2, x + 0.2, dy + 1.9, z + 0.2, M.metal);
        inst(unitBox, M.solar, x, dy + 2, z, 5, 0.14, 5, -0.27, 0, 0);
        for (let n = -2; n <= 2; n++) inst(unitBox, M.ivory, x + n, dy + 2.1, z, 0.025, 0.025, 5, -0.27, 0, 0);
      }
    }
  }
  wedge(dx - 5, dz + 4.5, dx - 1, dz + 11.5, dy, 4.15, 3, M.dark);
  pod(dx + 3, dz + 1.5, dy); pod(dx + 1, dz - 1, dy + 4.15);

  // CUMBRE: puesto blanco con pasarela elevada y antena parabólica.
  const nx = 22, nz = -94, ny = heightAt(nx, nz);
  landmark('CUMBRE BOREAL', nx, nz, '#cee8ef');
  mark(nx - 15, nz - 14, nx + 15, nz + 14);
  block(nx - 6, ny - 1, nz - 6, nx + 6, ny + 0.3, nz + 6, M.dark);
  block(nx - 6, ny + 0.3, nz - 6, nx + 6, ny + 4.5, nz - 5.5, M.ivory);
  block(nx - 6, ny + 0.3, nz - 5.5, nx - 5.5, ny + 4.5, nz + 5, M.ivory);
  block(nx + 5.5, ny + 0.3, nz - 5.5, nx + 6, ny + 4.5, nz + 5, M.ivory);
  block(nx - 6.4, ny + 4.5, nz - 6.4, nx + 6.4, ny + 4.85, nz + 6, M.teal);
  block(nx - 5.5, ny + 0.3, nz + 5, nx - 2, ny + 3.3, nz + 5.5, M.ivory);
  block(nx + 2, ny + 0.3, nz + 5, nx + 5.5, ny + 3.3, nz + 5.5, M.ivory);
  block(nx - 2, ny + 3.3, nz + 5, nx + 2, ny + 4.5, nz + 5.5, M.ivory);
  wedge(nx - 2.5, nz + 6, nx + 2.5, nz + 9, ny, 0.3, 3, M.dark);
  wedge(nx + 6.5, nz - 4, nx + 10.5, nz + 6, ny, 4.85, 3, M.dark);
  block(nx + 6, ny + 4.5, nz - 6, nx + 10.5, ny + 4.85, nz - 4, M.dark);
  block(nx - 0.4, ny + 4.85, nz - 0.4, nx + 0.4, ny + 8, nz + 0.4, M.metal);
  const dish = new THREE.Mesh(new THREE.SphereGeometry(3.3, 20, 8, 0, Math.PI * 2, 0, Math.PI * 0.42), std(0xe4eae4, { side: THREE.DoubleSide }));
  dish.position.set(nx, ny + 9, nz); dish.rotation.z = 0.48; dish.rotation.x = Math.PI; scene.add(dish);
  inst(trunkGeo, M.metal, nx, ny + 10.3, nz, 0.08, 5, 0.08, 0, 0, 0.48);
  pod(nx - 3, nz + 1.5, ny + 0.3); pod(nx + 3, nz - 2, ny + 4.85);

  // PUERTO: muelles, casas de servicio y una baliza costera.
  const hx = -20, hz = 112, hy = heightAt(hx, hz);
  landmark('PUERTO MAREA', hx, hz, '#72cccf');
  mark(hx - 14, hz - 13, hx + 14, hz + 19);
  for (const sx of [-1, 1]) {
    const cx = hx + sx * 9;
    block(cx - 3.5, hy - 0.5, hz - 7, cx + 3.5, hy + 3.3, hz - 6.6, M.teal);
    block(cx - 3.5, hy - 0.5, hz - 6.6, cx - 3.1, hy + 3.3, hz, M.ivory);
    block(cx + 3.1, hy - 0.5, hz - 6.6, cx + 3.5, hy + 3.3, hz, M.ivory);
    block(cx - 3.8, hy + 3.3, hz - 7.3, cx + 3.8, hy + 3.55, hz + 0.3, M.orange);
    crate(cx + 1, hy, hz - 3, M.yellow);
  }
  const deckY = Math.max(hy + 0.25, 2.3);
  block(hx - 3, deckY - 0.35, hz + 1, hx + 3, deckY, hz + 19, M.timber);
  wedge(hx - 3, hz - 3, hx + 3, hz + 1, hy, deckY - hy, 1, M.timber);
  if (!T.wood_planks) for (let z = hz + 1; z < hz + 19; z += 0.9) block(hx - 3, deckY, z, hx + 3, deckY + 0.025, z + 0.08, M.dark, false);
  for (const x of [hx - 2.7, hx + 2.7]) {
    for (let z = hz + 3; z < hz + 20; z += 4) block(x - 0.16, -1, z - 0.16, x + 0.16, deckY + 0.8, z + 0.16, M.timber);
  }
  block(hx + 6, hy, hz + 8, hx + 9, hy + 9, hz + 11, M.ivory);
  for (const yy of [2.5, 5.5]) block(hx + 5.98, hy + yy, hz + 7.98, hx + 9.02, hy + yy + 0.8, hz + 11.02, M.orange, false);
  block(hx + 5.6, hy + 9, hz + 7.6, hx + 9.4, hy + 9.3, hz + 11.4, M.metal, false);
  block(hx + 6.3, hy + 9.3, hz + 8.3, hx + 8.7, hy + 10.7, hz + 10.7, M.amber, false);
  inst(coneGeo, M.teal, hx + 7.5, hy + 11.7, hz + 9.5, 2.5, 2, 2.5);
  pod(hx - 9, hz - 1.6, hy); pod(hx + 0.7, hz + 15, deckY + 0.025);

  // Cobertura y cápsulas distribuidas en cada bioma, evitando las rutas.
  for (let i = 0, placed = 0; i < 1500 && placed < (dense ? 55 : 35); i++) {
    const x = (rng() - 0.5) * 260, z = (rng() - 0.5) * 260;
    if (!isLand(x, z, 10) || !clear(x, z, 3) || normalAt(x, z).y < 0.93 || Math.abs(x) < 5 || Math.abs(z) < 5) continue;
    const yy = heightAt(x, z), biome = biomeAt(x, z), width = 1.8 + rng() * 2.2, h = 1.1 + rng() * 1.5;
    if (Math.max(Math.abs(x), Math.abs(z)) < 45) {
      if (placed % 2) crate(x, yy, z, placed % 3 ? M.orange : M.teal);
      else barrier(x - 2, yy - 0.1, z - 0.3, x + 2, yy + 1.1, z + 0.3);
    } else {
      const mat = biome === 'desert' ? M.sandstone : biome === 'snow' ? M.snow : M.stone;
      const name = biome === 'desert' ? 'rock_sand' : biome === 'snow' ? 'rock_snow' : 'rock_grey', spin = rng() * 6.28;
      // El modelo se ajusta a la caja de colisión; solo gira media vuelta para no salirse de ella.
      if (has(name)) prop(name, x, yy - h * 0.12, z, width * 1.5, h * 1.2, width * 1.18, vr() < 0.5 ? 0 : Math.PI);
      else inst(rockGeo, mat, x, yy + h * 0.35, z, width, h, width * 0.8, 0, spin);
      world.addBox(x - width * 0.65, yy, z - width * 0.5, x + width * 0.65, yy + h * 0.95, z + width * 0.5);
    }
    mark(x - 2.5, z - 2.5, x + 2.5, z + 2.5); placed++;
  }
  for (let i = 0, placed = 0; i < 1000 && placed < 10; i++) {
    const x = (rng() - 0.5) * 240, z = (rng() - 0.5) * 240;
    if (!isLand(x, z, 15) || !clear(x, z, 4) || normalAt(x, z).y < 0.96) continue;
    pod(x, z); placed++;
  }

  // Vegetación por lotes: bosques amplios sin cientos de draw calls.
  const treeSpots = [];
  for (let i = 0; i < 2500 && treeSpots.length < 190; i++) {
    const x = (rng() - 0.5) * 290, z = (rng() - 0.5) * 290, b = biomeAt(x, z);
    if (!isLand(x, z, 6) || !clear(x, z, 3.5) || Math.max(Math.abs(x), Math.abs(z)) < 53 || normalAt(x, z).y < 0.84) continue;
    if (b === 'desert' || b === 'beach' || b === 'ocean' || (b === 'meadow' && rng() < 0.8)) continue;
    if (treeSpots.some(p => Math.hypot(p.x - x, p.z - z) < 5)) continue;
    treeSpots.push({ x, z });
    const yy = heightAt(x, z), h = 5 + rng() * 4, r = 1.9 + rng() * 1.3;
    const conifer = b === 'snow' || z < -50, trunk = conifer ? 0.26 : 0.4;
    const name = b === 'snow' ? 'tree_pine_snow' : conifer ? 'tree_pine' : 'tree_oak';
    const spins = [rng() * 6.28, rng() * 6.28, conifer ? rng() * 6.28 : 0];
    world.addBox(x - trunk, yy, z - trunk, x + trunk, yy + h * 0.7, z + trunk);
    if (has(name)) {
      const [w, th, d] = assets.natural(name, h * (conifer ? 1.3 : 1.1));
      prop(name, x, yy - 0.15, z, w, th, d, spins[0]);
      continue;
    }
    inst(trunkGeo, M.trunk, x, yy + h * 0.35, z, 0.32, h * 0.7, 0.32);
    if (conifer) {
      for (let layer = 0; layer < 3; layer++) {
        const rr = r * (1 - layer * 0.22);
        inst(coneGeo, M.pine, x, yy + h * (0.44 + layer * 0.2), z, rr, h * 0.5, rr, 0, spins[layer]);
        if (b === 'snow') inst(coneGeo, M.snow, x, yy + h * (0.53 + layer * 0.2), z, rr * 0.73, h * 0.34, rr * 0.73, 0, 0);
      }
    } else {
      inst(sphereGeo, M.forest, x, yy + h * 0.75, z, r * 1.1, h * 0.4, r, 0, spins[0]);
      inst(sphereGeo, M.grass, x + r * 0.45, yy + h * 0.9, z - r * 0.25, r * 0.8, h * 0.24, r * 0.8, 0, spins[1]);
    }
  }
  // Palmeras y cactus hacen reconocibles la costa y el sector árido.
  for (let i = 0, n = 0; i < 700 && n < 30; i++) {
    const x = (rng() - 0.5) * 285, z = (rng() - 0.5) * 285, b = biomeAt(x, z);
    if (!isLand(x, z, 4) || !clear(x, z, 4) || (b !== 'desert' && b !== 'beach')) continue;
    const yy = heightAt(x, z);
    if (b === 'desert') {
      if (has('cactus')) {
        const [w, h, d] = assets.natural('cactus', 3.4 + vr() * 1.2);
        prop('cactus', x, yy - 0.05, z, w, h, d, vr() * 6.28);
      } else {
        inst(trunkGeo, M.forest, x, yy + 1.65, z, 0.3, 3.3, 0.3);
        inst(trunkGeo, M.forest, x + 0.6, yy + 1.7, z, 0.18, 1.25, 0.18, 0, 0, Math.PI / 2);
        inst(trunkGeo, M.forest, x + 1.15, yy + 2.05, z, 0.19, 0.9, 0.19);
      }
    } else {
      const h = 5 + rng() * 2;
      if (has('palm')) {
        const [w, ph, d] = assets.natural('palm', h * 1.15);
        prop('palm', x, yy - 0.1, z, w, ph, d, vr() * 6.28);
      } else {
        inst(trunkGeo, M.trunk, x, yy + h / 2, z, 0.25, h, 0.25);
        for (let j = 0; j < 6; j++) {
          const a = j * Math.PI / 3, len = 2.8;
          inst(sphereGeo, M.forest, x + Math.cos(a) * 1.2, yy + h + 0.1, z + Math.sin(a) * 1.2, len, 0.16, 0.65, 0, -a, -0.15);
        }
      }
    }
    world.addBox(x - 0.22, yy, z - 0.22, x + 0.22, yy + 3.3, z + 0.22); n++;
  }
  // Matorrales y flores bajos no bloquean al jugador.
  for (let i = 0; i < 650; i++) {
    const x = (rng() - 0.5) * 275, z = (rng() - 0.5) * 275, b = biomeAt(x, z);
    if (!isLand(x, z, 5) || !clear(x, z, 1) || Math.max(Math.abs(x), Math.abs(z)) < 50 || !['forest', 'meadow'].includes(b)) continue;
    const yy = heightAt(x, z), r = 0.3 + rng() * 0.6, spin = rng() * 6.28;
    if (i % 8 === 0 && has('flowers')) {
      const [w, h, d] = assets.natural('flowers', 0.55 + r * 0.5);
      prop('flowers', x, yy - 0.03, z, w, h, d, spin);
    } else if (has('bush')) {
      prop('bush', x, yy - r * 0.15, z, r * 2.3, r * 1.5, r * 2.3, spin);
    } else {
      inst(sphereGeo, M.grass, x, yy + r * 0.45, z, r, r * 0.7, r, 0, spin);
      if (i % 8 === 0) inst(sphereGeo, M.yellow, x + 0.2, yy + r * 0.9, z, 0.1, 0.12, 0.1);
    }
  }

  // Hierbas bajas y grava en los bordes del distrito rompen el plano vacío
  // sin añadir obstáculos ni tapar las líneas de tiro entre edificios.
  const tuftGeo = new THREE.ConeGeometry(0.14, 0.4, 3);
  for (let i = 0; i < 160; i++) {
    const x = (rng() - 0.5) * 92, z = (rng() - 0.5) * 92;
    if (Math.abs(x) < 5 || Math.abs(z) < 5 || !clear(x, z, 0.7)) continue;
    if (i % 3 === 0 && Math.max(Math.abs(x), Math.abs(z)) > 30) {
      for (let j = 0; j < 4; j++) inst(tuftGeo, M.grass, x + j * 0.16, 4.15, z + (j % 2) * 0.16, 1, 0.6 + rng() * 0.5, 1, 0, rng() * 6.28);
    } else {
      const r = 0.055 + rng() * 0.08;
      inst(rockGeo, M.stone, x, 4 + r * 0.3, z, r, r * 0.6, r * 1.3, 0, rng() * 6.28);
    }
  }

  for (const { geo, material, transforms } of batches.values()) {
    const mesh = new THREE.InstancedMesh(geo, material, transforms.length);
    transforms.forEach((t, i) => {
      dummy.position.set(t[0], t[1], t[2]); dummy.scale.set(t[3], t[4], t[5]); dummy.rotation.set(t[6], t[7], t[8]);
      dummy.updateMatrix(); mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.castShadow = !geo.userData.noShadow;
    mesh.receiveShadow = true;
    mesh.computeBoundingSphere(); scene.add(mesh);
  }

  // Primera vista hacia el relé, las ruinas y las montañas; rivales en toda
  // la isla, siempre en suelo seco y libre, sin el antiguo fallback en paredes.
  const spawn = (x, z, gap) => {
    if (!world.isFree(x, z, 1.5) || world.pods.some(p => Math.hypot(p.x - x, p.z - z) < 3)) return false;
    if (world.spawns.some(p => Math.hypot(p.x - x, p.z - z) < gap)) return false;
    world.spawns.push({ x, y: heightAt(x, z), z }); return true;
  };
  spawn(-10, 40, 0);
  for (let i = 0; i < 6000 && world.spawns.length < 16; i++) {
    const a = rng() * Math.PI * 2, d = 24 + Math.sqrt(rng()) * 96;
    spawn(Math.cos(a) * d, Math.sin(a) * d, 28);
  }
  for (let z = -110; z <= 110 && world.spawns.length < 16; z += 8) {
    for (let x = -110; x <= 110 && world.spawns.length < 16; x += 8) spawn(x, z, 16);
  }
}

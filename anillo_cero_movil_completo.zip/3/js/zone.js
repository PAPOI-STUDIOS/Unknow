// El anillo: zona segura circular que se va cerrando por fases.
import * as THREE from 'three';
import { lerp } from './util.js';

const PHASES = [
  { hold: 60, shrink: 45, r: 100, dps: 2 },
  { hold: 35, shrink: 35, r: 52, dps: 4 },
  { hold: 25, shrink: 30, r: 22, dps: 7 },
  { hold: 12, shrink: 20, r: 1, dps: 12 },
];

export class Zone {
  constructor(game, x, z) {
    this.game = game;
    this.x = x; this.z = z;
    this.radius = 195;
    this.from = 195;
    this.phase = 0;
    this.closing = false;
    this.timer = PHASES[0].hold;
    this.dps = 1;
    this.tick = 0;
    this.done = false;

    this.wall = new THREE.Mesh(
      new THREE.CylinderGeometry(1, 1, 120, 96, 1, true),
      new THREE.ShaderMaterial({
        transparent: true, side: THREE.DoubleSide, depthWrite: false,
        uniforms: { time: { value: 0 }, strength: { value: 0.2 } },
        vertexShader: `varying vec2 vUv;
          void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
        fragmentShader: `varying vec2 vUv; uniform float time; uniform float strength;
          void main() {
            float fade = 1.0 - smoothstep(0.22, 0.95, vUv.y);
            float pulse = 0.85 + 0.15 * sin(vUv.y * 65.0 - time * 1.8);
            gl_FragColor = vec4(vec3(1.0, 0.34, 0.18), strength * fade * pulse);
          }`,
      }),
    );
    this.wall.position.set(x, 50, z);
    this.wall.renderOrder = 3;
    this.ring = new THREE.Mesh(
      new THREE.BufferGeometry(),
      new THREE.MeshBasicMaterial({ color: 0xffb08a, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false }),
    );
    const positions = new Float32Array(97 * 2 * 3), indices = [];
    for (let i = 0; i < 96; i++) indices.push(i * 2, i * 2 + 2, i * 2 + 1, i * 2 + 1, i * 2 + 2, i * 2 + 3);
    this.ring.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
    this.ring.geometry.setIndex(indices);
    this.ring.frustumCulled = false;
    game.scene.add(this.wall, this.ring);
    this.apply();
  }

  apply() {
    this.wall.scale.set(this.radius, 1, this.radius);
    const positions = this.ring.geometry.attributes.position;
    for (let i = 0; i <= 96; i++) for (let side = 0; side < 2; side++) {
      const angle = i / 96 * Math.PI * 2, r = Math.max(0, this.radius - side * 0.35);
      const x = this.x + Math.cos(angle) * r, z = this.z + Math.sin(angle) * r;
      positions.setXYZ(i * 2 + side, x, Math.max(0.65, this.game.world.groundHeight(x, z)) + 0.08, z);
    }
    positions.needsUpdate = true;
  }

  outside(x, z) {
    return Math.hypot(x - this.x, z - this.z) > this.radius;
  }

  get nextRadius() { return this.done ? this.radius : PHASES[this.phase].r; }

  update(dt) {
    if (!this.done) {
      const ph = PHASES[this.phase];
      this.timer -= dt;
      if (this.closing) {
        const t = 1 - Math.max(0, this.timer) / ph.shrink;
        this.radius = lerp(this.from, ph.r, t);
        if (this.timer <= 0) {
          this.radius = ph.r;
          this.closing = false;
          this.phase++;
          if (this.phase >= PHASES.length) this.done = true;
          else this.timer = PHASES[this.phase].hold;
        }
      } else if (this.timer <= 0) {
        this.closing = true;
        this.from = this.radius;
        this.timer = ph.shrink;
        this.dps = ph.dps;
        this.game.sfx.zone();
        this.game.hud.toast('¡El anillo se cierra!');
      }
      this.apply();
    }
    this.wall.material.uniforms.time.value = this.game.time;
    this.wall.material.uniforms.strength.value = 0.17 + 0.04 * Math.sin(this.game.time * 3);

    this.tick += dt;
    if (this.tick >= 1) {
      this.tick -= 1;
      for (const a of this.game.actors) {
        if (a.alive && this.outside(a.body.x, a.body.z)) this.game.damageActor(a, this.dps, null, false, null);
      }
    }
  }
}

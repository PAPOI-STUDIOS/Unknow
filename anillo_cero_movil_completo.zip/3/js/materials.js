// Materiales del mapa con textura proyectada en coordenadas del mundo.
import * as THREE from 'three';

export function std(color, extra) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0.05, flatShading: true, ...extra });
}

// Proyección triplanar: los bloques del mapa son cajas unidad escaladas, así que
// unas UV normales se estirarían. Proyectar desde el mundo mantiene el tamaño
// real de la textura en muros de cualquier largo y funciona con instancias.
export function triplanar(material, texture, scale = 0.33) {
  if (!texture) return material;
  material.onBeforeCompile = (shader) => {
    shader.uniforms.triMap = { value: texture };
    shader.uniforms.triScale = { value: scale };
    shader.vertexShader = 'varying vec3 vTriPos;\nvarying vec3 vTriNormal;\n' +
      shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
        vec4 triWorld = vec4(transformed, 1.0);
        vec3 triN = objectNormal;
        #ifdef USE_INSTANCING
          triWorld = instanceMatrix * triWorld;
          triN = mat3(instanceMatrix) * triN;
        #endif
        vTriPos = (modelMatrix * triWorld).xyz;
        vTriNormal = normalize(mat3(modelMatrix) * triN);`);
    shader.fragmentShader = 'uniform sampler2D triMap;\nuniform float triScale;\nvarying vec3 vTriPos;\nvarying vec3 vTriNormal;\n' +
      shader.fragmentShader.replace('#include <map_fragment>', `#include <map_fragment>
        vec3 triW = pow(abs(vTriNormal), vec3(8.0));
        triW /= triW.x + triW.y + triW.z;
        vec3 triColor = texture2D(triMap, vTriPos.zy * triScale).rgb * triW.x +
          texture2D(triMap, vTriPos.xz * triScale).rgb * triW.y +
          texture2D(triMap, vTriPos.xy * triScale).rgb * triW.z;
        diffuseColor.rgb *= triColor;`);
  };
  material.customProgramCacheKey = () => 'triplanar';
  return material;
}

// Follaje que se deshace en puntos al acercarse a la cámara: la vista en tercera
// persona puede quedar dentro de una copa, y sin esto la taparía por completo.
export function nearFade(material, from = 2.2, to = 4.4) {
  material.onBeforeCompile = (shader) => {
    shader.fragmentShader = shader.fragmentShader.replace('#include <clipping_planes_fragment>', `#include <clipping_planes_fragment>
      float fadeDistance = length(vViewPosition);
      if (fadeDistance < ${to.toFixed(2)}) {
        float fadeNoise = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
        if (fadeNoise > smoothstep(${from.toFixed(2)}, ${to.toFixed(2)}, fadeDistance)) discard;
      }`);
  };
  material.customProgramCacheKey = () => `nearFade:${from}:${to}`;
  return material;
}
